package net.coms.ten.teramod.block.renderer;

import software.bernie.geckolib.renderer.GeoBlockRenderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.MultiBufferSource;

import net.coms.ten.teramod.block.model.HiraisinsBlockModel;
import net.coms.ten.teramod.block.entity.HiraisinsTileEntity;

public class HiraisinsTileRenderer extends GeoBlockRenderer<HiraisinsTileEntity> {
	public HiraisinsTileRenderer() {
		super(new HiraisinsBlockModel());
	}

	@Override
	public RenderType getRenderType(HiraisinsTileEntity animatable, ResourceLocation texture, MultiBufferSource bufferSource, float partialTick) {
		return RenderType.entityTranslucent(getTextureLocation(animatable));
	}
}
