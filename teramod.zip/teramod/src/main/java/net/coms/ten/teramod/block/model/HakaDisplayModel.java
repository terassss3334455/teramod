package net.coms.ten.teramod.block.model;

import software.bernie.geckolib.model.GeoModel;

import net.minecraft.resources.ResourceLocation;

import net.coms.ten.teramod.block.display.HakaDisplayItem;

public class HakaDisplayModel extends GeoModel<HakaDisplayItem> {
	@Override
	public ResourceLocation getAnimationResource(HakaDisplayItem animatable) {
		return new ResourceLocation("teramod", "animations/hakka.animation.json");
	}

	@Override
	public ResourceLocation getModelResource(HakaDisplayItem animatable) {
		return new ResourceLocation("teramod", "geo/hakka.geo.json");
	}

	@Override
	public ResourceLocation getTextureResource(HakaDisplayItem entity) {
		return new ResourceLocation("teramod", "textures/block/hakatexture.png");
	}
}
