
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.coms.ten.teramod.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.Block;

import net.coms.ten.teramod.block.entity.HiraisinsTileEntity;
import net.coms.ten.teramod.block.entity.HakaTileEntity;
import net.coms.ten.teramod.TeramodMod;

public class TeramodModBlockEntities {
	public static final DeferredRegister<BlockEntityType<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCK_ENTITY_TYPES, TeramodMod.MODID);
	public static final RegistryObject<BlockEntityType<HiraisinsTileEntity>> HIRAISINS = REGISTRY.register("hiraisins", () -> BlockEntityType.Builder.of(HiraisinsTileEntity::new, TeramodModBlocks.HIRAISINS.get()).build(null));
	public static final RegistryObject<BlockEntityType<HakaTileEntity>> HAKA = REGISTRY.register("haka", () -> BlockEntityType.Builder.of(HakaTileEntity::new, TeramodModBlocks.HAKA.get()).build(null));

	// Start of user code block custom block entities
	// End of user code block custom block entities
	private static RegistryObject<BlockEntityType<?>> register(String registryname, RegistryObject<Block> block, BlockEntityType.BlockEntitySupplier<?> supplier) {
		return REGISTRY.register(registryname, () -> BlockEntityType.Builder.of(supplier, block.get()).build(null));
	}
}
