package net.coms.ten.teramod.block.model;

import software.bernie.geckolib.model.GeoModel;

import net.minecraft.resources.ResourceLocation;

import net.coms.ten.teramod.block.entity.HakaTileEntity;

public class HakaBlockModel extends GeoModel<HakaTileEntity> {
	@Override
	public ResourceLocation getAnimationResource(HakaTileEntity animatable) {
		return new ResourceLocation("teramod", "animations/hakka.animation.json");
	}

	@Override
	public ResourceLocation getModelResource(HakaTileEntity animatable) {
		return new ResourceLocation("teramod", "geo/hakka.geo.json");
	}

	@Override
	public ResourceLocation getTextureResource(HakaTileEntity animatable) {
		return new ResourceLocation("teramod", "textures/block/hakatexture.png");
	}
}
