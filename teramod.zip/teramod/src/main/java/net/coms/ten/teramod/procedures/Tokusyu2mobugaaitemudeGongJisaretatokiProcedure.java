package net.coms.ten.teramod.procedures;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.effect.MobEffectInstance;

import net.coms.ten.teramod.init.TeramodModMobEffects;

public class Tokusyu2mobugaaitemudeGongJisaretatokiProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		if (!(null == entity)) {
			if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
				_entity.addEffect(new MobEffectInstance(TeramodModMobEffects.STAN.get(), 200, 5, false, false));
		}
	}
}
