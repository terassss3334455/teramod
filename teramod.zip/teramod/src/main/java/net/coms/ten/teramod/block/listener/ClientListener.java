package net.coms.ten.teramod.block.listener;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.api.distmarker.Dist;

import net.coms.ten.teramod.init.TeramodModBlockEntities;
import net.coms.ten.teramod.block.renderer.HiraisinsTileRenderer;
import net.coms.ten.teramod.block.renderer.HakaTileRenderer;
import net.coms.ten.teramod.TeramodMod;

@Mod.EventBusSubscriber(modid = TeramodMod.MODID, bus = Mod.EventBusSubscriber.Bus.MOD)
public class ClientListener {
	@OnlyIn(Dist.CLIENT)
	@SubscribeEvent
	public static void registerRenderers(EntityRenderersEvent.RegisterRenderers event) {
		event.registerBlockEntityRenderer(TeramodModBlockEntities.HIRAISINS.get(), context -> new HiraisinsTileRenderer());
		event.registerBlockEntityRenderer(TeramodModBlockEntities.HAKA.get(), context -> new HakaTileRenderer());
	}
}
