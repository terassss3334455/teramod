package net.coms.ten.teramod.entity;

import software.bernie.geckolib.util.GeckoLibUtil;
import software.bernie.geckolib.core.object.PlayState;
import software.bernie.geckolib.core.animation.RawAnimation;
import software.bernie.geckolib.core.animation.AnimationState;
import software.bernie.geckolib.core.animation.AnimationController;
import software.bernie.geckolib.core.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.core.animation.AnimatableManager;
import software.bernie.geckolib.animatable.GeoEntity;

import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.network.PlayMessages;
import net.minecraftforge.network.NetworkHooks;

import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.world.level.Level;

import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.item.ItemStack;

import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobType;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.SpawnGroupData;

import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.FloatGoal;

import net.minecraft.world.entity.ai.goal.target.TargetGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;

import net.minecraft.world.entity.ai.navigation.PathNavigation;
import net.minecraft.world.entity.ai.navigation.FlyingPathNavigation;

import net.minecraft.world.entity.ai.control.FlyingMoveControl;

import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;

import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.damagesource.DamageSource;

import net.minecraft.sounds.SoundEvent;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.level.ServerBossEvent;

import net.minecraft.resources.ResourceLocation;

import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.EntityDataAccessor;

import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.Packet;

import net.minecraft.nbt.CompoundTag;

import net.coms.ten.teramod.procedures.KeruBOSSenteiteinotitukuGengXinShiProcedure;
import net.coms.ten.teramod.procedures.KeruBOSSenteiteigaSiWangsitaShiProcedure;

import net.coms.ten.teramod.init.TeramodModItems;
import net.coms.ten.teramod.init.TeramodModEntities;

import javax.annotation.Nullable;

import java.util.Comparator;
import java.util.EnumSet;
import java.util.List;


public class KeruBOSSEntity extends Monster implements GeoEntity {

    public static final EntityDataAccessor<Boolean> SHOOT =
        SynchedEntityData.defineId(
            KeruBOSSEntity.class,
            EntityDataSerializers.BOOLEAN
        );

    public static final EntityDataAccessor<String> ANIMATION =
        SynchedEntityData.defineId(
            KeruBOSSEntity.class,
            EntityDataSerializers.STRING
        );

    public static final EntityDataAccessor<String> TEXTURE =
        SynchedEntityData.defineId(
            KeruBOSSEntity.class,
            EntityDataSerializers.STRING
        );

    private final AnimatableInstanceCache cache =
        GeckoLibUtil.createInstanceCache(this);

    private final ServerBossEvent bossInfo =
        new ServerBossEvent(
            this.getDisplayName(),
            ServerBossEvent.BossBarColor.RED,
            ServerBossEvent.BossBarOverlay.PROGRESS
        );

    private static final String SERVANT_TAG =
        "KeruBOSS_Servant";

    private static final double TARGET_RANGE = 100.0D;

    /*
     * MCreatorのEntityAnimationFactory互換
     */
    public String animationprocedure = "undefined";


    public KeruBOSSEntity(
        EntityType<KeruBOSSEntity> type,
        Level world
    ) {
        super(type, world);

        this.xpReward = 0;

        this.setNoAi(false);

        this.setPersistenceRequired();

        this.setMaxUpStep(1.0F);

        this.moveControl =
            new FlyingMoveControl(
                this,
                20,
                true
            );

        /*
         * ブロックを無視
         */
        this.noPhysics = true;

        /*
         * 重力なし
         */
        this.setNoGravity(true);
    }


    /*
     * MCreatorのスポーンパケット用コンストラクタ
     */
    public KeruBOSSEntity(
        PlayMessages.SpawnEntity packet,
        Level world
    ) {
        this(
            TeramodModEntities.KERU_BOSS.get(),
            world
        );
    }


    /*
     * MCreatorから呼ばれるinit
     */
    public static void init() {
    }


    /*
     * =========================================================
     * Attributes
     * =========================================================
     */

    public static AttributeSupplier.Builder createAttributes() {

        return Monster.createMonsterAttributes()

            .add(
                Attributes.MOVEMENT_SPEED,
                4.0D
            )

            .add(
                Attributes.FLYING_SPEED,
                3.6D
            )

            .add(
                Attributes.MAX_HEALTH,
                655.0D
            )

            .add(
                Attributes.ARMOR,
                30.0D
            )

            .add(
                Attributes.ATTACK_DAMAGE,
                15.0D
            )

            .add(
                Attributes.FOLLOW_RANGE,
                100.0D
            )

            .add(
                Attributes.KNOCKBACK_RESISTANCE,
                1.0D
            )

            .add(
                Attributes.ATTACK_KNOCKBACK,
                20.0D
            );
    }


    /*
     * =========================================================
     * Navigation
     * =========================================================
     */

    @Override
    protected PathNavigation createNavigation(Level world) {

        FlyingPathNavigation navigation =
            new FlyingPathNavigation(
                this,
                world
            );

        navigation.setCanOpenDoors(true);
        navigation.setCanFloat(true);
        navigation.setCanPassDoors(true);

        return navigation;
    }


    /*
     * =========================================================
     * Goals
     * =========================================================
     */

    @Override
    protected void registerGoals() {

        /*
         * 直接追跡
         */
        this.goalSelector.addGoal(
            1,
            new DirectChaseGoal(this)
        );

        /*
         * 浮遊
         */
        this.goalSelector.addGoal(
            8,
            new FloatGoal(this)
        );

        /*
         * ランダムに見る
         */
        this.goalSelector.addGoal(
            9,
            new RandomLookAroundGoal(this)
        );


        /*
         * プレイヤー最優先
         *
         * 通常時に自動で敵対するのは
         * プレイヤーのみ。
         */
        this.targetSelector.addGoal(
            1,
            new PlayerTargetGoal(this)
        );


        /*
         * LivingEntity全般を自動ターゲットする
         * Goalは削除。
         *
         * その代わり、攻撃された場合は
         * HurtByTargetGoalによって反撃する。
         */
        this.targetSelector.addGoal(
            2,
            new HurtByTargetGoal(this)
        );
    }


    /*
     * =========================================================
     * 従者判定
     * =========================================================
     */

    private boolean isServantEntity(
        LivingEntity entity
    ) {

        if (entity == null)
            return true;

        if (entity == this)
            return true;

        if (this.getPassengers().contains(entity))
            return true;

        if (
            entity.isPassenger()
            && entity.getVehicle() == this
        ) {
            return true;
        }

        if (
            entity.getTags().contains(
                SERVANT_TAG
            )
        ) {
            return true;
        }

        if (
            entity instanceof TamableAnimal tamable
        ) {

            if (
                tamable.isTame()
                && tamable.getOwner() == this
            ) {
                return true;
            }
        }

        return false;
    }


    /*
     * =========================================================
     * プレイヤーターゲット
     * =========================================================
     */

    private static class PlayerTargetGoal
        extends TargetGoal {

        private final KeruBOSSEntity mob;

        public PlayerTargetGoal(
            KeruBOSSEntity mob
        ) {

            super(
                mob,
                true,
                false
            );

            this.mob = mob;
        }


        @Override
        public boolean canUse() {

            LivingEntity current =
                mob.getTarget();

            /*
             * 現在のターゲットが有効なプレイヤーなら
             * 新しいターゲットを探さない。
             */
            if (
                current instanceof Player player
                && player.isAlive()
                && !player.isCreative()
                && !player.isSpectator()
                && !mob.isServantEntity(player)
                && mob.distanceToSqr(player)
                    <= TARGET_RANGE * TARGET_RANGE
            ) {

                return false;
            }


            List<Player> players =
                mob.level().getEntitiesOfClass(
                    Player.class,
                    mob.getBoundingBox()
                        .inflate(TARGET_RANGE),

                    player ->
                        player.isAlive()
                        && !player.isCreative()
                        && !player.isSpectator()
                        && !mob.isServantEntity(player)
                );


            if (players.isEmpty())
                return false;


            Player target =
                players.stream()
                    .min(
                        Comparator.comparingDouble(
                            mob::distanceToSqr
                        )
                    )
                    .orElse(null);


            if (target == null)
                return false;


            mob.setTarget(target);

            return true;
        }


        @Override
        public boolean canContinueToUse() {

            LivingEntity target =
                mob.getTarget();


            if (!(target instanceof Player player))
                return false;

            if (!player.isAlive())
                return false;

            if (player.isCreative())
                return false;

            if (player.isSpectator())
                return false;

            if (mob.isServantEntity(player))
                return false;

            return mob.distanceToSqr(player)
                <= TARGET_RANGE * TARGET_RANGE;
        }
    }


    /*
     * =========================================================
     * 直接追跡AI
     * =========================================================
     */

    private static class DirectChaseGoal
        extends Goal {

        private final KeruBOSSEntity mob;

        private int attackCooldown = 0;

        /*
         * 前回のターゲット
         */
        private LivingEntity lastTarget = null;

        /*
         * テレポートのクールダウン
         *
         * 400tick = 約20秒
         */
        private int teleportCooldown = 0;


        public DirectChaseGoal(
            KeruBOSSEntity mob
        ) {

            this.mob = mob;

            this.setFlags(
                EnumSet.of(
                    Goal.Flag.MOVE,
                    Goal.Flag.LOOK
                )
            );
        }


        @Override
        public boolean canUse() {

            LivingEntity target =
                mob.getTarget();


            if (target == null)
                return false;

            if (!target.isAlive())
                return false;

            if (target == mob)
                return false;


            if (
                target instanceof Player player
            ) {

                if (player.isCreative())
                    return false;

                if (player.isSpectator())
                    return false;
            }


            if (mob.isServantEntity(target))
                return false;


            return true;
        }


        @Override
        public boolean canContinueToUse() {

            LivingEntity target =
                mob.getTarget();


            if (target == null)
                return false;

            if (!target.isAlive())
                return false;

            if (target == mob)
                return false;


            if (
                target instanceof Player player
            ) {

                if (player.isCreative())
                    return false;

                if (player.isSpectator())
                    return false;
            }


            if (mob.isServantEntity(target))
                return false;


            return true;
        }


        @Override
        public void start() {

            attackCooldown = 0;

            lastTarget = null;
        }


        @Override
        public void stop() {

            mob.setDeltaMovement(
                mob.getDeltaMovement()
                    .scale(0.5D)
            );

            lastTarget = null;
        }


        @Override
        public void tick() {

            LivingEntity target =
                mob.getTarget();


            if (target == null)
                return;


            /*
             * =================================================
             * テレポートクールダウン
             * =================================================
             */

            if (teleportCooldown > 0) {
                teleportCooldown--;
            }


            /*
             * =================================================
             * ターゲット変更時のテレポート
             *
             * クールダウン中はテレポートしない
             * =================================================
             */

            if (
                lastTarget != target
                && teleportCooldown <= 0
            ) {

                lastTarget = target;


                double angle =
                    mob.getRandom().nextDouble()
                    * Math.PI
                    * 2.0D;


                double teleportDistance =
                    2.5D
                    + mob.getRandom().nextDouble()
                    * 2.0D;


                double teleportX =
                    target.getX()
                    + Math.cos(angle)
                    * teleportDistance;


                double teleportY =
                    target.getY()
                    + target.getBbHeight()
                    * 0.5D;


                double teleportZ =
                    target.getZ()
                    + Math.sin(angle)
                    * teleportDistance;


                mob.teleportTo(
                    teleportX,
                    teleportY,
                    teleportZ
                );


                mob.setDeltaMovement(
                    0.0D,
                    0.0D,
                    0.0D
                );


                mob.getLookControl().setLookAt(
                    target,
                    30.0F,
                    30.0F
                );


                /*
                 * 400tick = 約20秒
                 */
                teleportCooldown = 400;
            }


            /*
             * =================================================
             * 距離計算
             * =================================================
             */

            double dx =
                target.getX()
                - mob.getX();


            double dy =
                (
                    target.getY()
                    + target.getBbHeight()
                    * 0.5D
                )
                -
                (
                    mob.getY()
                    + mob.getBbHeight()
                    * 0.5D
                );


            double dz =
                target.getZ()
                - mob.getZ();


            double distance =
                Math.sqrt(
                    dx * dx
                    + dy * dy
                    + dz * dz
                );


            if (distance < 0.001D)
                return;


            /*
             * =================================================
             * 移動方向
             * =================================================
             */

            double nx =
                dx / distance;

            double ny =
                dy / distance;

            double nz =
                dz / distance;


            /*
             * =================================================
             * 追跡速度
             * =================================================
             */

            double speed;


            if (distance > 30.0D) {

                speed = 2.0D;

            } else if (distance > 15.0D) {

                speed = 1.75D;

            } else if (distance > 8.0D) {

                speed = 1.5D;

            } else {

                speed = 0.8D;
            }


            /*
             * ターゲットへ一直線
             */
            mob.setDeltaMovement(
                nx * speed,
                ny * speed,
                nz * speed
            );


            /*
             * ターゲットを見る
             */
            mob.getLookControl().setLookAt(
                target,
                30.0F,
                30.0F
            );


            /*
             * =================================================
             * 攻撃
             * =================================================
             */

            if (attackCooldown > 0) {
                attackCooldown--;
            }


            double attackRange =
                mob.getBbWidth()
                + target.getBbWidth()
                + 2.5D;


            if (
                distance <= attackRange
                && attackCooldown <= 0
            ) {

                mob.doHurtTarget(target);

                attackCooldown = 10;
            }
        }
    }


    /*
     * =========================================================
     * ダメージ
     * =========================================================
     */

    @Override
    public boolean hurt(
        DamageSource source,
        float amount
    ) {

        if (
            source.is(DamageTypes.IN_FIRE)
            || source.is(DamageTypes.ON_FIRE)
            || source.is(DamageTypes.FALL)
            || source.is(DamageTypes.CACTUS)
            || source.is(DamageTypes.DROWN)
            || source.is(DamageTypes.LIGHTNING_BOLT)
            || source.is(DamageTypes.FALLING_ANVIL)
            || source.is(DamageTypes.DRAGON_BREATH)
            || source.is(DamageTypes.WITHER)
            || source.is(DamageTypes.WITHER_SKULL)
        ) {

            return false;
        }


        /*
         * 遠距離攻撃を受けた場合
         *
         * 攻撃者がLivingEntityなら
         * その相手をターゲットにする。
         *
         * そのため、他のモブから攻撃された場合も
         * そのモブに反撃する。
         */
        if (
            !this.level().isClientSide()
            && source.getDirectEntity()
                != source.getEntity()
        ) {

            Entity attackerEntity =
                source.getEntity();


            if (
                attackerEntity
                    instanceof LivingEntity attacker
            ) {

                if (
                    attacker.isAlive()
                    && !isServantEntity(attacker)
                ) {

                    double angle =
                        this.getRandom().nextDouble()
                        * Math.PI
                        * 2.0D;


                    double distance =
                        2.0D
                        + this.getRandom().nextDouble()
                        * 1.5D;


                    this.teleportTo(
                        attacker.getX()
                            + Math.cos(angle)
                            * distance,

                        attacker.getY()
                            + attacker.getBbHeight()
                            * 0.5D,

                        attacker.getZ()
                            + Math.sin(angle)
                            * distance
                    );


                    this.setTarget(attacker);
                }
            }
        }


        return super.hurt(
            source,
            amount
        );
    }


    /*
     * =========================================================
     * Tick
     * =========================================================
     */

    @Override
    public void baseTick() {

        super.baseTick();


        KeruBOSSenteiteinotitukuGengXinShiProcedure.execute(
            this.level(),
            this.getX(),
            this.getY(),
            this.getZ(),
            this
        );


        /*
         * 自動回復
         */
        if (
            this.tickCount % 20 == 0
            && this.isAlive()
        ) {

            float healAmount = 1.0F;


            if (
                this.getHealth()
                < this.getMaxHealth() * 0.5F
            ) {

                healAmount = 2.0F;
            }


            this.heal(
                healAmount
            );
        }


        /*/*
 * =========================================================
 * Idle中のふわふわ浮遊
 * =========================================================
 *
 * ターゲットがいないときだけ実行。
 *
 * noGravity / noPhysics はそのままなので、
 * ブロックをすり抜ける性質も維持。
 */
if (this.getTarget() == null) {

    double floatY =
        Math.sin(
            (this.tickCount + this.getId()) * 0.08D
        ) * 0.025D;

    this.setDeltaMovement(
        this.getDeltaMovement().x() * 0.9D,
        floatY,
        this.getDeltaMovement().z() * 0.9D
    );
}


        /*
         * 持ち上げ攻撃
         */
        if (
            this.tickCount % 100 == 0
        ) {

            LivingEntity target =
                this.getTarget();


            if (
                target != null
                && target.isAlive()
                && target != this
                && !isServantEntity(target)
                && !target.isPassenger()
                && this.distanceTo(target)
                    <= 20.0D
            ) {

                target.startRiding(
                    this,
                    true
                );
            }
        }


        /*
         * 持ち上げ中
         */
        if (
            !this.getPassengers().isEmpty()
        ) {

            this.setDeltaMovement(
                this.getDeltaMovement().x(),
                0.5D,
                this.getDeltaMovement().z()
            );


            if (
                this.tickCount % 40 == 0
            ) {

                for (
                    Entity passenger
                    : this.getPassengers()
                ) {

                    passenger.stopRiding();


                    passenger.setDeltaMovement(
                        passenger.getDeltaMovement().x(),
                        -1.0D,
                        passenger.getDeltaMovement().z()
                    );
                }
            }
        }
    }


    /*
     * =========================================================
     * Spawn
     * =========================================================
     */

    @Override
    public SpawnGroupData finalizeSpawn(
        ServerLevelAccessor world,
        DifficultyInstance difficulty,
        MobSpawnType reason,
        @Nullable SpawnGroupData livingdata,
        @Nullable CompoundTag tag
    ) {

        return super.finalizeSpawn(
            world,
            difficulty,
            reason,
            livingdata,
            tag
        );
    }


    /*
     * =========================================================
     * 死亡
     * =========================================================
     */

    @Override
    public void die(
        DamageSource source
    ) {

        KeruBOSSenteiteigaSiWangsitaShiProcedure.execute(
            this.level(),
            this.getX(),
            this.getY(),
            this.getZ()
        );


        super.die(source);
    }


    /*
     * =========================================================
     * BossBar
     * =========================================================
     */

    @Override
    public void startSeenByPlayer(
        ServerPlayer player
    ) {

        super.startSeenByPlayer(player);

        bossInfo.addPlayer(player);
    }


    @Override
    public void stopSeenByPlayer(
        ServerPlayer player
    ) {

        super.stopSeenByPlayer(player);

        bossInfo.removePlayer(player);
    }


    @Override
    public void aiStep() {

        super.aiStep();

        bossInfo.setProgress(
            this.getHealth()
                / this.getMaxHealth()
        );
    }


    /*
     * =========================================================
     * Animation
     * =========================================================
     */

    public String getAnimation() {

        return this.entityData.get(
            ANIMATION
        );
    }


    public String getSyncedAnimation() {

        return this.entityData.get(
            ANIMATION
        );
    }


    public void setAnimation(
        String animation
    ) {

        this.entityData.set(
            ANIMATION,
            animation
        );

        this.animationprocedure =
            animation;
    }


    private PlayState predicate(
        AnimationState event
    ) {

        if (
            this.getAnimation()
                .equals("attack")
        ) {

            return event.setAndContinue(
                RawAnimation.begin()
                    .thenPlay("attack")
            );
        }


        return event.setAndContinue(
            RawAnimation.begin()
                .thenLoop("idle")
        );
    }


    @Override
    public void registerControllers(
        AnimatableManager.ControllerRegistrar data
    ) {

        data.add(
            new AnimationController<>(
                this,
                "controller",
                0,
                this::predicate
            )
        );
    }


    @Override
    public AnimatableInstanceCache
        getAnimatableInstanceCache() {

        return cache;
    }


    /*
     * =========================================================
     * Synched Data
     * =========================================================
     */

    @Override
    protected void defineSynchedData() {

        super.defineSynchedData();


        this.entityData.define(
            SHOOT,
            false
        );


        this.entityData.define(
            ANIMATION,
            "undefined"
        );


        this.entityData.define(
            TEXTURE,
            "keru2texture"
        );
    }


    /*
     * =========================================================
     * Texture
     * =========================================================
     */

    public String getTexture() {

        return this.entityData.get(
            TEXTURE
        );
    }


    public void setTexture(
        String texture
    ) {

        this.entityData.set(
            TEXTURE,
            texture
        );
    }


    @Override
    public void addAdditionalSaveData(
        CompoundTag compound
    ) {

        super.addAdditionalSaveData(
            compound
        );


        compound.putString(
            "Texture",
            this.getTexture()
        );
    }


    @Override
    public void readAdditionalSaveData(
        CompoundTag compound
    ) {

        super.readAdditionalSaveData(
            compound
        );


        if (
            compound.contains("Texture")
        ) {

            this.setTexture(
                compound.getString("Texture")
            );
        }
    }


    /*
     * =========================================================
     * Entity properties
     * =========================================================
     */

    @Override
    public MobType getMobType() {

        return MobType.UNDEFINED;
    }


    @Override
    public boolean removeWhenFarAway(
        double distanceToClosestPlayer
    ) {

        return false;
    }


    @Override
    public boolean isPushable() {

        return false;
    }


    @Override
    protected void doPush(
        Entity entity
    ) {
    }


    @Override
    protected void pushEntities() {
    }


    @Override
    public boolean canBeCollidedWith() {

        return true;
    }


    @Override
    public boolean canCollideWith(
        Entity entity
    ) {

        return false;
    }


    /*
     * =========================================================
     * Loot
     * =========================================================
     */

    @Override
    protected void dropCustomDeathLoot(
        DamageSource source,
        int looting,
        boolean recentlyHit
    ) {

        super.dropCustomDeathLoot(
            source,
            looting,
            recentlyHit
        );


        this.spawnAtLocation(
            new ItemStack(
                TeramodModItems.TOKUSYU_2.get()
            )
        );
    }


    /*
     * =========================================================
     * Spawn packet
     * =========================================================
     */

    @Override
    public Packet<ClientGamePacketListener>
        getAddEntityPacket() {

        return NetworkHooks.getEntitySpawningPacket(
            this
        );
    }


    /*
     * =========================================================
     * MCreator SpawnEntity
     * =========================================================
     */

    public static KeruBOSSEntity createInstance(
        PlayMessages.SpawnEntity packet,
        Level world
    ) {

        return new KeruBOSSEntity(
            packet,
            world
        );
    }


    /*
     * =========================================================
     * Sounds
     * =========================================================
     */

    @Override
    public SoundEvent getHurtSound(
        DamageSource ds
    ) {

        return ForgeRegistries.SOUND_EVENTS.getValue(
            new ResourceLocation(
                "entity.generic.hurt"
            )
        );
    }


    @Override
    public SoundEvent getDeathSound() {

        return ForgeRegistries.SOUND_EVENTS.getValue(
            new ResourceLocation(
                "entity.generic.death"
            )
        );
    }


    @Override
    public boolean fireImmune() {

        return true;
    }
}