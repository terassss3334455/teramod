package net.coms.ten.teramod.procedures;

import net.minecraft.world.entity.Entity;

public class KeruBOSSenteiteigasuponsitaShiProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		entity.getPersistentData().putDouble("kerutime", 0);
		entity.getPersistentData().putDouble("keruon", 0);
	}
}
