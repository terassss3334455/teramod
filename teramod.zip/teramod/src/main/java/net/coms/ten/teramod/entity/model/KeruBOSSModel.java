package net.coms.ten.teramod.entity.model;

import software.bernie.geckolib.model.GeoModel;

import net.minecraft.resources.ResourceLocation;

import net.coms.ten.teramod.entity.KeruBOSSEntity;

public class KeruBOSSModel extends GeoModel<KeruBOSSEntity> {
	@Override
	public ResourceLocation getAnimationResource(KeruBOSSEntity entity) {
		return new ResourceLocation("teramod", "animations/keru2.animation.json");
	}

	@Override
	public ResourceLocation getModelResource(KeruBOSSEntity entity) {
		return new ResourceLocation("teramod", "geo/keru2.geo.json");
	}

	@Override
	public ResourceLocation getTextureResource(KeruBOSSEntity entity) {
		return new ResourceLocation("teramod", "textures/entities/" + entity.getTexture() + ".png");
	}

}
