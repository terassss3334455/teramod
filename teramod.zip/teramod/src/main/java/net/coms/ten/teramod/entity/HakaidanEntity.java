package net.coms.ten.teramod.entity;

import software.bernie.geckolib.util.GeckoLibUtil;
import software.bernie.geckolib.core.object.PlayState;
import software.bernie.geckolib.core.animation.RawAnimation;
import software.bernie.geckolib.core.animation.AnimationState;
import software.bernie.geckolib.core.animation.AnimationController;
import software.bernie.geckolib.core.animation.AnimatableManager;
import software.bernie.geckolib.core.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.animatable.GeoEntity;

import net.coms.ten.teramod.procedures.HakaidanenteiteinotitukuGengXinShiProcedure;
import net.coms.ten.teramod.procedures.HakaidanenteiteigasuponsitaShiProcedure;
import net.coms.ten.teramod.init.TeramodModEntities;

import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.network.PlayMessages;
import net.minecraftforge.network.NetworkHooks;

import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.ai.navigation.PathNavigation;
import net.minecraft.world.entity.ai.navigation.FlyingPathNavigation;
import net.minecraft.world.entity.ai.control.FlyingMoveControl;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.SpawnGroupData;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.entity.MobType;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EntityDimensions;

import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.damagesource.DamageSource;

import net.minecraft.sounds.SoundEvent;
import net.minecraft.resources.ResourceLocation;

import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.EntityDataAccessor;

import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.Packet;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.core.BlockPos;

import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import javax.annotation.Nullable;

import java.util.Comparator;
import java.util.List;


/*
 * ============================================================
 * ハカイダン
 *
 * ・半径50ブロック以内のプレイヤーを最優先
 * ・クリエイティブのプレイヤーは対象外
 * ・スペクテイターのプレイヤーは対象外
 * ・プレイヤーがいなければLivingEntityを追跡
 * ・HakaidanEntityは追跡対象外
 * ・HakaidanEntityに接触しても爆発しない
 * ・KeruBOSSEntityは追跡対象外
 * ・KeruBOSSEntityに接触しても爆発しない
 * ・その他のLivingEntityに接触すると爆発力10
 * ・地面に接触しても爆発力10
 * ・爆発後は即デスポーン
 * ・null、死亡Entity対策あり
 * ============================================================
 */
public class HakaidanEntity extends Monster implements GeoEntity {

	public static final EntityDataAccessor<Boolean> SHOOT =
			SynchedEntityData.defineId(
					HakaidanEntity.class,
					EntityDataSerializers.BOOLEAN
			);

	public static final EntityDataAccessor<String> ANIMATION =
			SynchedEntityData.defineId(
					HakaidanEntity.class,
					EntityDataSerializers.STRING
			);

	public static final EntityDataAccessor<String> TEXTURE =
			SynchedEntityData.defineId(
					HakaidanEntity.class,
					EntityDataSerializers.STRING
			);

	private final AnimatableInstanceCache cache =
			GeckoLibUtil.createInstanceCache(this);

	private boolean swinging;
	private boolean lastloop;
	private long lastSwing;

	public String animationprocedure = "empty";

	/*
	 * 二重爆発防止
	 */
	private boolean exploded = false;


	public HakaidanEntity(
			PlayMessages.SpawnEntity packet,
			Level world
	) {
		this(
				TeramodModEntities.HAKAIDAN.get(),
				world
		);
	}


	public HakaidanEntity(
			EntityType<HakaidanEntity> type,
			Level world
	) {
		super(type, world);

		xpReward = 0;

		setNoAi(false);
		setMaxUpStep(0.6f);
		setPersistenceRequired();

		/*
		 * 飛行用MoveControl
		 */
		this.moveControl = new FlyingMoveControl(
				this,
				10,
				true
		);
	}


	@Override
	protected void defineSynchedData() {
		super.defineSynchedData();

		this.entityData.define(
				SHOOT,
				false
		);

		this.entityData.define(
				ANIMATION,
				"undefined"
		);

		this.entityData.define(
				TEXTURE,
				"hakaitexture"
		);
	}


	public void setTexture(String texture) {
		this.entityData.set(
				TEXTURE,
				texture
		);
	}


	public String getTexture() {
		return this.entityData.get(
				TEXTURE
		);
	}


	@Override
	public Packet<ClientGamePacketListener> getAddEntityPacket() {
		return NetworkHooks.getEntitySpawningPacket(
				this
		);
	}


	@Override
	protected PathNavigation createNavigation(Level world) {
		return new FlyingPathNavigation(
				this,
				world
		);
	}


	/*
	 * ============================================================
	 * AI Goal
	 *
	 * 通常のMeleeAttackGoalは使用しない。
	 * tick()内でターゲットを取得して直接飛行させる。
	 * ============================================================
	 */
	@Override
	protected void registerGoals() {
		super.registerGoals();
	}


	@Override
	public MobType getMobType() {
		return MobType.UNDEFINED;
	}


	@Override
	public boolean removeWhenFarAway(
			double distanceToClosestPlayer
	) {
		return false;
	}


	@Override
	public SoundEvent getHurtSound(
			DamageSource ds
	) {
		return ForgeRegistries.SOUND_EVENTS.getValue(
				new ResourceLocation(
						"entity.generic.hurt"
				)
		);
	}


	@Override
	public SoundEvent getDeathSound() {
		return ForgeRegistries.SOUND_EVENTS.getValue(
				new ResourceLocation(
						"entity.generic.death"
				)
		);
	}


	@Override
	public boolean causeFallDamage(
			float l,
			float d,
			DamageSource source
	) {
		return false;
	}


	/*
	 * ============================================================
	 * ダメージ処理
	 *
	 * hurt()から爆発Procedureを呼ばない。
	 *
	 * 爆発によるダメージで再度爆発してしまう
	 * 無限ループを防止。
	 * ============================================================
	 */
	@Override
	public boolean hurt(
			DamageSource source,
			float amount
	) {

		if (source.is(DamageTypes.WITHER))
			return false;

		if (source.is(DamageTypes.WITHER_SKULL))
			return false;

		return super.hurt(
				source,
				amount
		);
	}


	@Override
	public SpawnGroupData finalizeSpawn(
			ServerLevelAccessor world,
			net.minecraft.world.DifficultyInstance difficulty,
			MobSpawnType reason,
			@Nullable SpawnGroupData livingdata,
			@Nullable CompoundTag tag
	) {

		SpawnGroupData retval =
				super.finalizeSpawn(
						world,
						difficulty,
						reason,
						livingdata,
						tag
				);

		HakaidanenteiteigasuponsitaShiProcedure.execute(
				world,
				this.getX(),
				this.getY(),
				this.getZ(),
				this
		);

		return retval;
	}


	@Override
	public void addAdditionalSaveData(
			CompoundTag compound
	) {

		super.addAdditionalSaveData(
				compound
		);

		compound.putString(
				"Texture",
				this.getTexture()
		);
	}


	@Override
	public void readAdditionalSaveData(
			CompoundTag compound
	) {

		super.readAdditionalSaveData(
				compound
		);

		if (compound.contains("Texture")) {

			this.setTexture(
					compound.getString(
							"Texture"
					)
			);
		}
	}


	@Override
	public void baseTick() {

		super.baseTick();

		HakaidanenteiteinotitukuGengXinShiProcedure.execute(
				this.level(),
				this.getX(),
				this.getY(),
				this.getZ()
		);

		this.refreshDimensions();
	}


	@Override
	public EntityDimensions getDimensions(
			Pose pose
	) {

		return super.getDimensions(
				pose
		).scale(
				1.0f
		);
	}


	/*
	 * ============================================================
	 * プレイヤーとの接触
	 * ============================================================
	 */
	@Override
	public void playerTouch(
			Player sourceentity
	) {

		super.playerTouch(
				sourceentity
		);

		/*
		 * クリエイティブ・スペクテイターは
		 * 接触しても爆発対象にしない。
		 */
		if (
				sourceentity != null
				&& sourceentity.isAlive()
				&& !sourceentity.isCreative()
				&& !sourceentity.isSpectator()
				&& !this.level().isClientSide
				&& !this.exploded
		) {

			explodeAndRemove();
		}
	}


	@Override
	protected void checkFallDamage(
			double y,
			boolean onGroundIn,
			BlockState state,
			BlockPos pos
	) {
		/*
		 * 落下ダメージ無効
		 */
	}


	@Override
	public void setNoGravity(
			boolean ignored
	) {

		super.setNoGravity(
				true
		);
	}


	@Override
	public void aiStep() {

		super.aiStep();

		this.setNoGravity(
				true
		);
	}


	/*
	 * ============================================================
	 * 爆発処理
	 * ============================================================
	 */
	private void explodeAndRemove() {

		/*
		 * 二重爆発防止
		 */
		if (this.exploded)
			return;

		this.exploded = true;

		/*
		 * クライアント側では処理しない
		 */
		if (this.level().isClientSide)
			return;

		/*
		 * 爆発力10
		 *
		 * BLOCK:
		 * ブロックを破壊する爆発
		 */
		this.level().explode(
				this,
				this.getX(),
				this.getY(),
				this.getZ(),
				10.0F,
				Level.ExplosionInteraction.BLOCK
		);

		/*
		 * 即デスポーン
		 */
		this.discard();
	}


	/*
	 * ============================================================
	 * ターゲット検索
	 *
	 * 優先順位
	 *
	 * 1. 通常プレイヤー
	 * 2. その他LivingEntity
	 *
	 * 完全除外
	 *
	 * ・クリエイティブプレイヤー
	 * ・スペクテイタープレイヤー
	 * ・HakaidanEntity
	 * ・KeruBOSSEntity
	 * ============================================================
	 */
	@Nullable
	private LivingEntity findTarget() {

		if (this.level() == null)
			return null;


		/*
		 * 半径50ブロック
		 */
		AABB searchBox =
				this.getBoundingBox().inflate(
						50.0D
				);


		/*
		 * ========================================================
		 * 1. プレイヤー最優先
		 * ========================================================
		 */
		List<Player> players =
				this.level().getEntitiesOfClass(
						Player.class,
						searchBox,
						player ->
								player != null
								&& player.isAlive()
								&& !player.isCreative()
								&& !player.isSpectator()
				);


		if (!players.isEmpty()) {

			return players.stream()
					.min(
							Comparator.comparingDouble(
									player ->
											this.distanceToSqr(
													player
											)
							)
					)
					.orElse(null);
		}


		/*
		 * ========================================================
		 * 2. プレイヤーがいなければLivingEntity
		 * ========================================================
		 */
		List<LivingEntity> livingEntities =
				this.level().getEntitiesOfClass(
						LivingEntity.class,
						searchBox,
						entity -> {

							if (entity == null)
								return false;

							if (entity == this)
								return false;

							if (!entity.isAlive())
								return false;


							/*
							 * Hakaidan同士を完全除外
							 */
							if (entity instanceof HakaidanEntity)
								return false;


							/*
							 * KeruBOSSを完全除外
							 */
							if (entity instanceof KeruBOSSEntity)
								return false;


							/*
							 * Playerはここでも確認。
							 *
							 * PlayerはLivingEntityでもあるため、
							 * 上のプレイヤー検索で除外された
							 * Creative/Spectatorがここで
							 * 再び対象になるのを防ぐ。
							 */
							if (entity instanceof Player) {

								Player player =
										(Player) entity;

								if (player.isCreative())
									return false;

								if (player.isSpectator())
									return false;
							}


							return true;
						}
				);


		if (!livingEntities.isEmpty()) {

			return livingEntities.stream()
					.min(
							Comparator.comparingDouble(
									entity ->
											this.distanceToSqr(
													entity
											)
							)
					)
					.orElse(null);
		}


		return null;
	}


	/*
	 * ============================================================
	 * LivingEntityとの接触判定
	 *
	 * 以下は完全に無視：
	 *
	 * ・自分自身
	 * ・HakaidanEntity
	 * ・KeruBOSSEntity
	 * ・クリエイティブプレイヤー
	 * ・スペクテイタープレイヤー
	 * ============================================================
	 */
	private boolean isTouchingLivingEntity() {

		if (this.level() == null)
			return false;


		AABB checkBox =
				this.getBoundingBox().inflate(
						0.15D
				);


		List<LivingEntity> entities =
				this.level().getEntitiesOfClass(
						LivingEntity.class,
						checkBox,
						entity -> {

							if (entity == null)
								return false;

							if (entity == this)
								return false;

							if (!entity.isAlive())
								return false;


							/*
							 * Hakaidan同士は無視
							 */
							if (entity instanceof HakaidanEntity)
								return false;


							/*
							 * KeruBOSSは無視
							 */
							if (entity instanceof KeruBOSSEntity)
								return false;


							/*
							 * プレイヤーの場合
							 */
							if (entity instanceof Player) {

								Player player =
										(Player) entity;

								/*
								 * Creative無視
								 */
								if (player.isCreative())
									return false;

								/*
								 * Spectator無視
								 */
								if (player.isSpectator())
									return false;
							}


							return true;
						}
				);


		return !entities.isEmpty();
	}


	/*
	 * ============================================================
	 * 毎tick
	 * ============================================================
	 */
	@Override
	public void tick() {

		super.tick();


		/*
		 * すでに削除済みなら何もしない
		 */
		if (this.isRemoved())
			return;


		/*
		 * サーバー側だけで処理
		 */
		if (!this.level().isClientSide) {


			/*
			 * ====================================================
			 * 1. 地面に触れた
			 * ====================================================
			 */
			if (
					this.onGround()
					|| this.verticalCollisionBelow
			) {

				explodeAndRemove();

				return;
			}


			/*
			 * ====================================================
			 * 2. LivingEntityに接触
			 * ====================================================
			 */
			if (isTouchingLivingEntity()) {

				explodeAndRemove();

				return;
			}


			/*
			 * ====================================================
			 * 3. ターゲット取得
			 * ====================================================
			 */
			LivingEntity target =
					findTarget();


			/*
			 * 対象がいない場合
			 */
			if (
					target == null
					|| !target.isAlive()
			) {

				/*
				 * 現在速度を徐々に減速
				 */
				Vec3 velocity =
						this.getDeltaMovement();

				this.setDeltaMovement(
						velocity.scale(
								0.95D
						)
				);

				return;
			}


			/*
			 * ====================================================
			 * 4. ターゲット位置
			 * ====================================================
			 */
			Vec3 targetPos =
					target.position();


			/*
			 * ターゲットの中心を狙う
			 */
			targetPos =
					targetPos.add(
							0.0D,
							target.getBbHeight()
									* 0.5D,
							0.0D
					);


			Vec3 currentPos =
					this.position();


			Vec3 direction =
					targetPos.subtract(
							currentPos
					);


			double distance =
					direction.length();


			/*
			 * 距離がほぼ0の場合
			 */
			if (distance <= 0.001D)
				return;


			/*
			 * ====================================================
			 * 5. ターゲット方向へ飛行
			 * ====================================================
			 */
			Vec3 normalized =
					direction.normalize();


			/*
			 * 基本速度
			 */
			double speed = 0.65D;


			/*
			 * 近づくほど加速
			 */
			if (distance < 15.0D) {
				speed = 0.85D;
			}


			if (distance < 7.0D) {
				speed = 1.05D;
			}


			/*
			 * 現在速度
			 */
			Vec3 currentVelocity =
					this.getDeltaMovement();


			/*
			 * 目標速度
			 */
			Vec3 desiredVelocity =
					normalized.scale(
							speed
					);


			/*
			 * 現在速度25%
			 * 新しい方向75%
			 */
			Vec3 newVelocity =
					currentVelocity.scale(
							0.25D
					).add(
							desiredVelocity.scale(
									0.75D
							)
					);


			/*
			 * 最大速度
			 */
			double maxSpeed = 1.2D;


			if (
					newVelocity.length()
							> maxSpeed
			) {

				newVelocity =
						newVelocity.normalize()
								.scale(
										maxSpeed
								);
			}


			/*
			 * 移動
			 */
			this.setDeltaMovement(
					newVelocity
			);


			/*
			 * ====================================================
			 * 6. 向きを進行方向へ
			 * ====================================================
			 */
			this.setYRot(
					(float) (
							Math.atan2(
									newVelocity.z,
									newVelocity.x
							)
							* (180.0D / Math.PI)
					) - 90.0F
			);


			this.yRotO =
					this.getYRot();


			/*
			 * 上下方向
			 */
			double horizontalDistance =
					Math.sqrt(
							newVelocity.x
									* newVelocity.x
							+
							newVelocity.z
									* newVelocity.z
					);


			if (
					horizontalDistance
							> 0.001D
			) {

				this.setXRot(
						(float) (
								-(
										Math.atan2(
												newVelocity.y,
												horizontalDistance
										)
										* (180.0D / Math.PI)
								)
						)
				);

				this.xRotO =
						this.getXRot();
			}
		}
	}


	/*
	 * ============================================================
	 * Attributes
	 * ============================================================
	 */
	public static void init() {
	}


	public static AttributeSupplier.Builder createAttributes() {

		AttributeSupplier.Builder builder =
				Mob.createMobAttributes();


		builder = builder.add(
				Attributes.MOVEMENT_SPEED,
				0.3
		);


		builder = builder.add(
				Attributes.MAX_HEALTH,
				50
		);


		builder = builder.add(
				Attributes.ARMOR,
				0
		);


		builder = builder.add(
				Attributes.ATTACK_DAMAGE,
				20
		);


		builder = builder.add(
				Attributes.FOLLOW_RANGE,
				50
		);


		builder = builder.add(
				Attributes.KNOCKBACK_RESISTANCE,
				100
		);


		builder = builder.add(
				Attributes.ATTACK_KNOCKBACK,
				10
		);


		builder = builder.add(
				Attributes.FLYING_SPEED,
				0.3
		);


		return builder;
	}


	/*
	 * ============================================================
	 * GeckoLib
	 * ============================================================
	 */
	private PlayState movementPredicate(
			AnimationState event
	) {

		if (
				this.animationprocedure.equals(
						"empty"
				)
		) {

			return event.setAndContinue(
					RawAnimation.begin()
							.thenLoop(
									"idle"
							)
			);
		}

		return PlayState.STOP;
	}


	String prevAnim = "empty";


	private PlayState procedurePredicate(
			AnimationState event
	) {

		if (
				(
						!animationprocedure.equals(
								"empty"
						)
						&& event.getController()
								.getAnimationState()
								== AnimationController.State.STOPPED
				)
				||
				(
						!this.animationprocedure.equals(
								prevAnim
						)
						&& !this.animationprocedure.equals(
								"empty"
						)
				)
		) {

			if (
					!this.animationprocedure.equals(
							prevAnim
					)
			) {

				event.getController()
						.forceAnimationReset();
			}


			event.getController()
					.setAnimation(
							RawAnimation.begin()
									.thenPlay(
											this.animationprocedure
									)
					);


			if (
					event.getController()
							.getAnimationState()
							== AnimationController.State.STOPPED
			) {

				this.animationprocedure =
						"empty";

				event.getController()
						.forceAnimationReset();
			}

		} else if (
				animationprocedure.equals(
						"empty"
				)
		) {

			prevAnim =
					"empty";

			return PlayState.STOP;
		}


		prevAnim =
				this.animationprocedure;


		return PlayState.CONTINUE;
	}


	@Override
	protected void tickDeath() {

		++this.deathTime;


		if (this.deathTime == 20) {

			this.remove(
					HakaidanEntity.RemovalReason.KILLED
			);

			this.dropExperience();
		}
	}


	public String getSyncedAnimation() {

		return this.entityData.get(
				ANIMATION
		);
	}


	public void setAnimation(
			String animation
	) {

		this.entityData.set(
				ANIMATION,
				animation
		);
	}


	@Override
	public void registerControllers(
			AnimatableManager.ControllerRegistrar data
	) {

		data.add(
				new AnimationController<>(
						this,
						"movement",
						4,
						this::movementPredicate
				)
		);


		data.add(
				new AnimationController<>(
						this,
						"procedure",
						4,
						this::procedurePredicate
				)
		);
	}


	@Override
	public AnimatableInstanceCache getAnimatableInstanceCache() {

		return this.cache;
	}
}