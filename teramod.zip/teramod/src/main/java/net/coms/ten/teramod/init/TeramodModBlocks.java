
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.coms.ten.teramod.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;

import net.coms.ten.teramod.block.HiraisinsBlock;
import net.coms.ten.teramod.block.HakaBlock;
import net.coms.ten.teramod.TeramodMod;

public class TeramodModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, TeramodMod.MODID);
	public static final RegistryObject<Block> HIRAISINS = REGISTRY.register("hiraisins", () -> new HiraisinsBlock());
	public static final RegistryObject<Block> HAKA = REGISTRY.register("haka", () -> new HakaBlock());
	// Start of user code block custom blocks
	// End of user code block custom blocks
}
