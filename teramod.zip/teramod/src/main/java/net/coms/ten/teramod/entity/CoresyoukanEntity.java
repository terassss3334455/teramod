package net.coms.ten.teramod.entity;

import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.network.PlayMessages;
import net.minecraftforge.network.NetworkHooks;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Holder;
import net.minecraft.core.HolderSet;
import net.minecraft.core.registries.Registries;

import net.minecraft.server.level.ServerLevel;

import net.minecraft.world.level.Level;
import net.minecraft.world.level.levelgen.structure.Structure;

import net.minecraft.world.item.ItemStack;

import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.projectile.ItemSupplier;
import net.minecraft.world.entity.projectile.AbstractArrow;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.EntityType;

import net.minecraft.util.RandomSource;

import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;

import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;

import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.Packet;

import net.coms.ten.teramod.init.TeramodModItems;
import net.coms.ten.teramod.init.TeramodModEntities;

import javax.annotation.Nullable;

import com.mojang.datafixers.util.Pair;


public class CoresyoukanEntity extends AbstractArrow implements ItemSupplier {

    public static final ItemStack PROJECTILE_ITEM =
            new ItemStack(TeramodModItems.SYOUKANKORE.get());

    @Nullable
    private BlockPos targetStructurePos = null;


    /*
     * =========================
     * 飛行設定
     * =========================
     */

    // 飛ぶ最高速度
    private static final double FLY_SPEED = 0.45D;

    // 加速の強さ
    private static final double ACCELERATION = 0.15D;

    /*
     * 構造物の方向へ飛び続ける時間
     *
     * 20tick = 1秒
     * 100tick = 5秒
     */
    private static final int FLY_TICKS = 100;

    /*
     * 飛行後にその場で待つ時間
     *
     * 60tick = 約3秒
     */
    private static final int WAIT_TICKS = 60;


    /*
     * =========================
     * 構造物検索設定
     * =========================
     */

    private static final int SEARCH_RADIUS = 100;


    /*
     * =========================
     * 状態
     * =========================
     */

    // 何tick飛んだか
    private int flyTimer = 0;

    // 飛行終了後、何tick待っているか
    private int waitTimer = 0;

    // 方向へ飛ぶ段階
    private boolean flyingToDirection = true;

    // 待機中か
    private boolean waiting = false;


    /*
     * 20%で消滅
     * 80%でアイテムをドロップ
     */
    private static final int BREAK_CHANCE = 5;


    /*
     * =========================
     * 構造物
     * =========================
     */

    private static final ResourceKey<Structure> TARGET_STRUCTURE =
            ResourceKey.create(
                    Registries.STRUCTURE,
                    new ResourceLocation("teramod", "sinden")
            );


    /*
     * =========================
     * コンストラクタ
     * =========================
     */

    public CoresyoukanEntity(
            PlayMessages.SpawnEntity packet,
            Level world
    ) {
        super(
                TeramodModEntities.CORESYOUKAN.get(),
                world
        );

        this.setNoGravity(true);
    }


    public CoresyoukanEntity(
            EntityType<? extends CoresyoukanEntity> type,
            Level world
    ) {
        super(type, world);

        this.setNoGravity(true);
    }


    public CoresyoukanEntity(
            EntityType<? extends CoresyoukanEntity> type,
            double x,
            double y,
            double z,
            Level world
    ) {
        super(type, x, y, z, world);

        this.setNoGravity(true);
    }


    public CoresyoukanEntity(
            EntityType<? extends CoresyoukanEntity> type,
            LivingEntity entity,
            Level world
    ) {
        super(type, entity, world);

        this.setNoGravity(true);
    }


    @Override
    public boolean isNoGravity() {
        return true;
    }


    /*
     * =========================
     * ネットワーク
     * =========================
     */

    @Override
    public Packet<ClientGamePacketListener> getAddEntityPacket() {
        return NetworkHooks.getEntitySpawningPacket(this);
    }


    /*
     * =========================
     * アイテム
     * =========================
     */

    @Override
    public ItemStack getItem() {
        return PROJECTILE_ITEM;
    }


    @Override
    protected ItemStack getPickupItem() {
        return PROJECTILE_ITEM;
    }


    /*
     * =========================
     * 構造物を検索
     * =========================
     */

    public void findTargetStructure() {

        if (this.level().isClientSide()) {
            return;
        }

        if (!(this.level() instanceof ServerLevel serverLevel)) {
            return;
        }


        var registry =
                serverLevel.registryAccess()
                        .registryOrThrow(Registries.STRUCTURE);


        var holderOptional =
                registry.getHolder(TARGET_STRUCTURE);


        if (holderOptional.isEmpty()) {

            System.out.println(
                    "[Teramod] teramod:sinden が構造物レジストリに見つかりません。"
            );

            return;
        }


        Holder<Structure> holder =
                holderOptional.get();


        HolderSet<Structure> holderSet =
                HolderSet.direct(holder);


        Pair<BlockPos, Holder<Structure>> result =
                serverLevel
                        .getChunkSource()
                        .getGenerator()
                        .findNearestMapStructure(
                                serverLevel,
                                holderSet,
                                this.blockPosition(),
                                SEARCH_RADIUS,
                                false
                        );


        if (result != null) {

            this.targetStructurePos =
                    result.getFirst();


            System.out.println(
                    "[Teramod] Sinden detected at "
                    + this.targetStructurePos
            );
        }
    }


    /*
     * =========================
     * Tick
     * =========================
     */

    @Override
    public void tick() {

        this.setNoGravity(true);

        super.tick();


        if (this.level().isClientSide()) {
            return;
        }


        /*
         * =====================================
         * ① 構造物の方向へ飛んでいる段階
         * =====================================
         */

        if (flyingToDirection) {

            /*
             * 構造物が見つかっていない場合
             */
            if (targetStructurePos == null) {

                findTargetStructure();

                return;
            }


            /*
             * 構造物の「方向」へ飛ぶ
             *
             * 構造物そのものへ到着することはない。
             */
            flyTowardStructureDirection();


            flyTimer++;


            /*
             * 一定時間飛んだら終了
             */
            if (flyTimer >= FLY_TICKS) {

                flyingToDirection = false;
                waiting = true;

                waitTimer = 0;


                /*
                 * その場で停止
                 */
                this.setDeltaMovement(
                        0.0D,
                        0.0D,
                        0.0D
                );


                System.out.println(
                        "[Teramod] Coresyoukan stopped after showing direction."
                );
            }


            return;
        }


        /*
         * =====================================
         * ② 飛行終了後、約3秒待つ
         * =====================================
         */

        if (waiting) {

            /*
             * 完全に停止
             */
            this.setDeltaMovement(
                    0.0D,
                    0.0D,
                    0.0D
            );


            waitTimer++;


            /*
             * 約3秒経過
             */
            if (waitTimer >= WAIT_TICKS) {

                waiting = false;

                finish();
            }
        }
    }


    /*
     * =========================
     * 構造物の「方向」へ飛ばす
     * =========================
     */

    private void flyTowardStructureDirection() {

        if (targetStructurePos == null) {
            return;
        }


        /*
         * 構造物の中心付近
         *
         * ここでは「到着判定」には使わない。
         * あくまで方向を計算するためだけに使う。
         */

        double targetX =
                targetStructurePos.getX() + 0.5D;

        double targetY =
                targetStructurePos.getY() + 2.0D;

        double targetZ =
                targetStructurePos.getZ() + 0.5D;


        /*
         * 現在位置 → 構造物
         */

        double dx =
                targetX - this.getX();

        double dy =
                targetY - this.getY();

        double dz =
                targetZ - this.getZ();


        /*
         * 距離
         */

        double distance =
                Math.sqrt(
                        dx * dx
                        + dy * dy
                        + dz * dz
                );


        if (distance <= 0.001D) {
            return;
        }


        /*
         * 単位ベクトル化
         */

        dx /= distance;
        dy /= distance;
        dz /= distance;


        /*
         * 現在の速度
         */

        double vx =
                this.getDeltaMovement().x;

        double vy =
                this.getDeltaMovement().y;

        double vz =
                this.getDeltaMovement().z;


        /*
         * 目標速度
         */

        double targetVX =
                dx * FLY_SPEED;

        double targetVY =
                dy * FLY_SPEED;

        double targetVZ =
                dz * FLY_SPEED;


        /*
         * 徐々に加速
         */

        vx +=
                (targetVX - vx)
                * ACCELERATION;

        vy +=
                (targetVY - vy)
                * ACCELERATION;

        vz +=
                (targetVZ - vz)
                * ACCELERATION;


        /*
         * 速度上限
         */

        double speed =
                Math.sqrt(
                        vx * vx
                        + vy * vy
                        + vz * vz
                );


        if (speed > FLY_SPEED) {

            double scale =
                    FLY_SPEED / speed;

            vx *= scale;
            vy *= scale;
            vz *= scale;
        }


        /*
         * 移動
         */

        this.setDeltaMovement(
                vx,
                vy,
                vz
        );


        /*
         * 飛んでいる方向を向く
         */

        this.setYRot(
                (float)(
                        Math.atan2(vz, vx)
                        * (180.0D / Math.PI)
                ) - 90.0F
        );


        this.setXRot(
                (float)(
                        -Math.atan2(
                                vy,
                                Math.sqrt(
                                        vx * vx
                                        + vz * vz
                                )
                        )
                        * (180.0D / Math.PI)
                )
        );


        this.yRotO =
                this.getYRot();

        this.xRotO =
                this.getXRot();
    }


    /*
     * =========================
     * 飛行終了後の処理
     * =========================
     */

    private void finish() {

        /*
         * 20%で消滅
         */
        if (this.random.nextInt(BREAK_CHANCE) == 0) {

            playEnderEyeDeathSound();


            System.out.println(
                    "[Teramod] Coresyoukan disappeared."
            );


            this.discard();

            return;
        }


        /*
         * =========================
         * アイテムをドロップ
         * =========================
         */

        ItemStack drop =
                new ItemStack(
                        TeramodModItems.SYOUKANKORE.get()
                );


        ItemEntity itemEntity =
                new ItemEntity(
                        this.level(),
                        this.getX(),
                        this.getY(),
                        this.getZ(),
                        drop
                );


        /*
         * 少しだけ浮かせる
         */
        itemEntity.setDeltaMovement(
                0.0D,
                0.15D,
                0.0D
        );


        this.level().addFreshEntity(
                itemEntity
        );


        /*
         * エンダーアイの消滅音
         */
        playEnderEyeDeathSound();


        System.out.println(
                "[Teramod] Coresyoukan dropped Syoukankore."
        );


        /*
         * 本体消滅
         */
        this.discard();
    }


    /*
     * =========================
     * エンダーアイ消滅音
     * =========================
     */

    private void playEnderEyeDeathSound() {

        SoundEvent sound =
                ForgeRegistries.SOUND_EVENTS.getValue(
                        new ResourceLocation(
                                "minecraft",
                                "entity.ender_eye.death"
                        )
                );


        if (sound != null) {

            this.level().playSound(
                    null,
                    this.getX(),
                    this.getY(),
                    this.getZ(),
                    sound,
                    SoundSource.NEUTRAL,
                    1.0F,
                    1.0F
            );
        }
    }


    /*
     * =========================
     * ダメージ処理
     * =========================
     */

    @Override
    protected void doPostHurtEffects(
            LivingEntity entity
    ) {

        super.doPostHurtEffects(entity);

        entity.setArrowCount(
                entity.getArrowCount() - 1
        );
    }


    /*
     * =========================
     * 射撃
     * =========================
     */

    public static CoresyoukanEntity shoot(
            Level world,
            LivingEntity entity,
            RandomSource source
    ) {

        return shoot(
                world,
                entity,
                source,
                1f,
                5,
                5
        );
    }


    public static CoresyoukanEntity shoot(
            Level world,
            LivingEntity entity,
            RandomSource source,
            float pullingPower
    ) {

        return shoot(
                world,
                entity,
                source,
                pullingPower,
                5,
                5
        );
    }


    public static CoresyoukanEntity shoot(
            Level world,
            LivingEntity entity,
            RandomSource random,
            float power,
            double damage,
            int knockback
    ) {

        CoresyoukanEntity entityarrow =
                new CoresyoukanEntity(
                        TeramodModEntities.CORESYOUKAN.get(),
                        entity,
                        world
                );


        entityarrow.shoot(
                entity.getViewVector(1).x,
                entity.getViewVector(1).y,
                entity.getViewVector(1).z,
                power * 2,
                0
        );


        entityarrow.setSilent(true);

        entityarrow.setCritArrow(false);

        entityarrow.setBaseDamage(
                damage
        );

        entityarrow.setKnockback(
                knockback
        );

        entityarrow.setNoGravity(true);


        /*
         * サーバー側で構造物の方向を取得
         */

        if (!world.isClientSide()) {

            entityarrow.findTargetStructure();
        }


        world.addFreshEntity(
                entityarrow
        );


        /*
         * 発射音
         */

        world.playSound(
                null,
                entity.getX(),
                entity.getY(),
                entity.getZ(),
                ForgeRegistries.SOUND_EVENTS.getValue(
                        new ResourceLocation(
                                "entity.arrow.shoot"
                        )
                ),
                SoundSource.PLAYERS,
                1.0F,
                1.0F
        );


        return entityarrow;
    }


    /*
     * =========================
     * ターゲット射撃
     * =========================
     */

    public static CoresyoukanEntity shoot(
            LivingEntity entity,
            LivingEntity target
    ) {

        CoresyoukanEntity entityarrow =
                new CoresyoukanEntity(
                        TeramodModEntities.CORESYOUKAN.get(),
                        entity,
                        entity.level()
                );


        double dx =
                target.getX()
                - entity.getX();


        double dy =
                target.getY()
                + target.getEyeHeight()
                - 1.1D;


        double dz =
                target.getZ()
                - entity.getZ();


        entityarrow.shoot(
                dx,
                dy
                        - entityarrow.getY()
                        + Math.hypot(dx, dz)
                        * 0.2F,
                dz,
                2.0F,
                12.0F
        );


        entityarrow.setSilent(true);

        entityarrow.setBaseDamage(5);

        entityarrow.setKnockback(5);

        entityarrow.setCritArrow(false);

        entityarrow.setNoGravity(true);


        if (!entity.level().isClientSide()) {

            entityarrow.findTargetStructure();
        }


        entity.level().addFreshEntity(
                entityarrow
        );


        return entityarrow;
    }
}