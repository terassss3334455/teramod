package net.coms.ten.teramod.block.model;

import software.bernie.geckolib.model.GeoModel;

import net.minecraft.resources.ResourceLocation;

import net.coms.ten.teramod.block.display.HiraisinsDisplayItem;

public class HiraisinsDisplayModel extends GeoModel<HiraisinsDisplayItem> {
	@Override
	public ResourceLocation getAnimationResource(HiraisinsDisplayItem animatable) {
		return new ResourceLocation("teramod", "animations/hiraisin.animation.json");
	}

	@Override
	public ResourceLocation getModelResource(HiraisinsDisplayItem animatable) {
		return new ResourceLocation("teramod", "geo/hiraisin.geo.json");
	}

	@Override
	public ResourceLocation getTextureResource(HiraisinsDisplayItem entity) {
		return new ResourceLocation("teramod", "textures/block/hiraisintexture.png");
	}
}
