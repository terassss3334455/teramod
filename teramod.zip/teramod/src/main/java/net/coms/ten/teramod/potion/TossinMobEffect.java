package net.coms.ten.teramod.potion;

import net.coms.ten.teramod.init.TeramodModMobEffects;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.entity.living.MobEffectEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

public class TossinMobEffect extends MobEffect {

    /*
     * =========================================================
     * 基本設定
     * =========================================================
     */

    /*
     * 通常持続時間
     *
     * 60tick = 3秒
     */
    private static final int BASE_DURATION = 60;

    /*
     * 通常は2秒後に予備線
     *
     * 40tick = 2秒
     */
    private static final int PREVIEW_AFTER_TICKS = 40;

    /*
     * 突進距離
     */
    private static final double DASH_DISTANCE = 15.0D;

    /*
     * 突進時間
     *
     * 10tick = 0.5秒
     */
    private static final int DASH_TICKS = 4;

    /*
     * 1tickあたりの突進距離
     */
    private static final double DASH_SPEED =
        DASH_DISTANCE / DASH_TICKS;

    /*
     * 衝突判定範囲
     */
    private static final double HIT_RANGE = 1.0D;

    /*
     * STAN持続時間
     *
     * 200tick = 10秒
     */
    private static final int STAN_DURATION = 200;

    /*
     * =========================================================
     * 突進前の浮上設定
     * =========================================================
     */

    /*
     * 突進直前に少し浮かせる高さ
     *
     * 0.5ブロック
     */
    private static final double DASH_LIFT_HEIGHT = 0.5D;

    /*
     * =========================================================
     * PersistentDataキー
     * =========================================================
     */

    private static final String TOSSIN_ELAPSED_TICKS =
        "TossinElapsedTicks";

    private static final String PREVIEW_SHOWN =
        "TossinPreviewShown";

    private static final String DASHING =
        "TossinDashing";

    private static final String DASH_DIRECTION_X =
        "TossinDashDirectionX";

    private static final String DASH_DIRECTION_Y =
        "TossinDashDirectionY";

    private static final String DASH_DIRECTION_Z =
        "TossinDashDirectionZ";

    private static final String DASH_TICKS_REMAINING =
        "TossinDashTicksRemaining";

    private static final String HIT_ENTITY_PREFIX =
        "TossinHit_";


    /*
     * =========================================================
     * コンストラクタ
     * =========================================================
     */

    public TossinMobEffect() {

        super(
            MobEffectCategory.NEUTRAL,
            -1
        );

        MinecraftForge.EVENT_BUS.register(this);
    }


    /*
     * =========================================================
     * Instantではない
     * =========================================================
     */

    @Override
    public boolean isInstantenous() {
        return false;
    }


    /*
     * =========================================================
     * エフェクト付与イベント
     * =========================================================
     */

    @SubscribeEvent
    public void onEffectAdded(
        MobEffectEvent.Added event
    ) {

        if (event == null) {
            return;
        }

        LivingEntity entity =
            event.getEntity();

        if (entity == null) {
            return;
        }

        Level level =
            entity.level();

        if (level == null) {
            return;
        }

        if (level.isClientSide()) {
            return;
        }

        MobEffectInstance addedEffect =
            event.getEffectInstance();

        if (addedEffect == null) {
            return;
        }

        if (addedEffect.getEffect() != this) {
            return;
        }


        /*
         * =====================================================
         * 以前のTossin
         * =====================================================
         */

        MobEffectInstance oldEffect =
            event.getOldEffectInstance();


        /*
         * =====================================================
         * 初回付与
         * =====================================================
         */

        if (oldEffect == null) {

            resetTossinState(
                entity
            );

            /*
             * 付与した瞬間から炎を出す
             */
            spawnBodyFlames(
                entity
            );

            return;
        }


        /*
         * =====================================================
         * 再付与
         * =====================================================
         *
         * 残り時間 + 新規時間
         */

        int oldDuration =
            Math.max(
                0,
                oldEffect.getDuration()
            );

        int newDuration =
            Math.max(
                0,
                addedEffect.getDuration()
            );

        long combinedDurationLong =
            (long) oldDuration
            + (long) newDuration;

        int combinedDuration;

        if (
            combinedDurationLong
            > Integer.MAX_VALUE
        ) {

            combinedDuration =
                Integer.MAX_VALUE;

        } else {

            combinedDuration =
                (int) combinedDurationLong;
        }


        /*
         * =====================================================
         * レベル加算
         * =====================================================
         *
         * Lv1 + Lv2 = Lv3
         */

        int oldLevel =
            Math.max(
                1,
                oldEffect.getAmplifier() + 1
            );

        int newLevel =
            Math.max(
                1,
                addedEffect.getAmplifier() + 1
            );

        long combinedLevelLong =
            (long) oldLevel
            + (long) newLevel;

        int combinedLevel;

        if (
            combinedLevelLong
            > Integer.MAX_VALUE
        ) {

            combinedLevel =
                Integer.MAX_VALUE;

        } else {

            combinedLevel =
                (int) combinedLevelLong;
        }

        int combinedAmplifier =
            Math.max(
                0,
                combinedLevel - 1
            );


        /*
         * =====================================================
         * 現在の状態保存
         * =====================================================
         */

        CompoundTag data =
            entity.getPersistentData();

        int oldElapsed =
            data.getInt(
                TOSSIN_ELAPSED_TICKS
            );

        boolean oldPreviewShown =
            data.getBoolean(
                PREVIEW_SHOWN
            );

        boolean wasDashing =
            data.getBoolean(
                DASHING
            );

        int oldDashRemaining =
            data.getInt(
                DASH_TICKS_REMAINING
            );

        double oldDirectionX =
            data.getDouble(
                DASH_DIRECTION_X
            );

        double oldDirectionY =
            data.getDouble(
                DASH_DIRECTION_Y
            );

        double oldDirectionZ =
            data.getDouble(
                DASH_DIRECTION_Z
            );


        /*
         * =====================================================
         * いったん旧エフェクト削除
         * =====================================================
         */

        entity.removeEffect(
            this
        );


        /*
         * =====================================================
         * 合算したエフェクト
         * =====================================================
         */

        MobEffectInstance combinedEffect =
            new MobEffectInstance(
                this,
                combinedDuration,
                combinedAmplifier,
                false,
                true
            );

        entity.addEffect(
            combinedEffect
        );


        /*
         * =====================================================
         * 状態復元
         * =====================================================
         */

        data.putInt(
            TOSSIN_ELAPSED_TICKS,
            Math.max(
                0,
                oldElapsed
            )
        );

        data.putBoolean(
            PREVIEW_SHOWN,
            oldPreviewShown
        );

        data.putBoolean(
            DASHING,
            wasDashing
        );

        data.putInt(
            DASH_TICKS_REMAINING,
            oldDashRemaining
        );

        data.putDouble(
            DASH_DIRECTION_X,
            oldDirectionX
        );

        data.putDouble(
            DASH_DIRECTION_Y,
            oldDirectionY
        );

        data.putDouble(
            DASH_DIRECTION_Z,
            oldDirectionZ
        );


        /*
         * 再付与時にも炎
         */

        spawnBodyFlames(
            entity
        );
    }


    /*
     * =========================================================
     * 毎tick処理
     * =========================================================
     */

    @Override
    public void applyEffectTick(
        LivingEntity entity,
        int amplifier
    ) {

        if (entity == null) {
            return;
        }

        Level level =
            entity.level();

        if (level == null) {
            return;
        }

        if (level.isClientSide()) {
            return;
        }


        /*
         * =====================================================
         * 突進中
         * =====================================================
         */

        if (
            entity.getPersistentData()
                .getBoolean(DASHING)
        ) {

            tickDash(
                entity,
                amplifier
            );

            return;
        }


        /*
         * =====================================================
         * 現在のTossin
         * =====================================================
         */

        MobEffectInstance effect =
            entity.getEffect(this);

        if (effect == null) {
            return;
        }


        /*
         * =====================================================
         * 経過時間
         * =====================================================
         */

        int elapsed =
            entity.getPersistentData()
                .getInt(
                    TOSSIN_ELAPSED_TICKS
                );

        elapsed++;

        if (elapsed < 0) {
            elapsed =
                Integer.MAX_VALUE;
        }

        entity.getPersistentData()
            .putInt(
                TOSSIN_ELAPSED_TICKS,
                elapsed
            );


        /*
         * =====================================================
         * 身体の炎
         * =====================================================
         */

        spawnBodyFlames(
            entity
        );


        /*
         * =====================================================
         * 現在の残り時間
         * =====================================================
         */

        int duration =
            Math.max(
                0,
                effect.getDuration()
            );


        /*
         * =====================================================
         * 元々の総時間
         * =====================================================
         */

        int originalDuration =
            getOriginalDuration(
                entity,
                effect,
                elapsed
            );


        /*
         * =====================================================
         * 予備線タイミング
         * =====================================================
         */

        int previewTick =
            calculatePreviewTick(
                originalDuration
            );


        /*
         * =====================================================
         * 予備線表示
         * =====================================================
         */

        if (
            !entity.getPersistentData()
                .getBoolean(PREVIEW_SHOWN)
            && elapsed >= previewTick
        ) {

            /*
             * ここで15ブロック全部表示
             */
            showDashPreview(
                entity
            );

            entity.getPersistentData()
                .putBoolean(
                    PREVIEW_SHOWN,
                    true
                );
        }


        /*
         * =====================================================
         * 突進開始
         * =====================================================
         *
         * 通常60tickなら終了1tick前ではなく、
         * 予備線を出した直後のタイミングで開始。
         *
         * これにより
         *
         * 予備線
         * ↓
         * 少し浮く
         * ↓
         * 突進
         *
         * になる。
         */

        if (
            duration <= 1
            && !entity.getPersistentData()
                .getBoolean(DASHING)
        ) {

            /*
             * 予備線がまだなら必ず出す
             */

            if (
                !entity.getPersistentData()
                    .getBoolean(PREVIEW_SHOWN)
            ) {

                showDashPreview(
                    entity
                );

                entity.getPersistentData()
                    .putBoolean(
                        PREVIEW_SHOWN,
                        true
                    );
            }


            /*
             * 突進開始
             *
             * この中で少し浮かせる。
             */

            startDash(
                entity,
                amplifier
            );


            /*
             * 重要
             *
             * ここではTossinを削除しない。
             *
             * 突進10tickの間もこのMobEffectのtickを
             * 継続させる。
             *
             * 突進完了後にfinishDash()で削除する。
             */

            return;
        }
    }


    /*
     * =========================================================
     * 予備線タイミング計算
     * =========================================================
     */

    private int calculatePreviewTick(
        int totalDuration
    ) {

        if (totalDuration <= 1) {
            return 1;
        }


        /*
         * 2秒以上なら40tick後
         */

        if (
            totalDuration
            >= PREVIEW_AFTER_TICKS
        ) {

            return PREVIEW_AFTER_TICKS;
        }


        /*
         * 2秒未満なら
         * 総時間の約2/3経過時
         */

        int calculated =
            (int) Math.ceil(
                totalDuration
                * 0.6666667D
            );

        return Math.max(
            1,
            calculated
        );
    }


    /*
     * =========================================================
     * 総持続時間取得
     * =========================================================
     */

    private int getOriginalDuration(
        LivingEntity entity,
        MobEffectInstance effect,
        int elapsed
    ) {

        if (
            entity == null
            || effect == null
        ) {
            return BASE_DURATION;
        }

        int currentDuration =
            Math.max(
                0,
                effect.getDuration()
            );

        long total =
            (long) elapsed
            + (long) currentDuration;

        if (total <= 0) {
            return BASE_DURATION;
        }

        if (
            total
            > Integer.MAX_VALUE
        ) {
            return Integer.MAX_VALUE;
        }

        return (int) total;
    }


    /*
     * =========================================================
     * Effect Tick
     * =========================================================
     */

    @Override
    public boolean isDurationEffectTick(
        int duration,
        int amplifier
    ) {

        return true;
    }


    /*
     * =========================================================
     * 身体の炎
     * =========================================================
     */

    private void spawnBodyFlames(
        LivingEntity entity
    ) {

        if (entity == null) {
            return;
        }

        Level level =
            entity.level();

        if (level == null) {
            return;
        }

        if (!(level instanceof ServerLevel serverLevel)) {
            return;
        }


        for (int i = 0; i < 6; i++) {

            double x =
                entity.getX()
                + (
                    entity.getRandom().nextDouble()
                    - 0.5D
                )
                * Math.max(
                    0.1D,
                    entity.getBbWidth()
                );

            double y =
                entity.getY()
                + entity.getRandom().nextDouble()
                * Math.max(
                    0.1D,
                    entity.getBbHeight()
                );

            double z =
                entity.getZ()
                + (
                    entity.getRandom().nextDouble()
                    - 0.5D
                )
                * Math.max(
                    0.1D,
                    entity.getBbWidth()
                );


            serverLevel.sendParticles(
                ParticleTypes.FLAME,
                x,
                y,
                z,
                1,
                0.0D,
                0.0D,
                0.0D,
                0.0D
            );
        }
    }


    /*
     * =========================================================
     * 予備線
     * =========================================================
     */

    private void showDashPreview(
        LivingEntity entity
    ) {

        if (entity == null) {
            return;
        }

        Level level =
            entity.level();

        if (level == null) {
            return;
        }

        if (!(level instanceof ServerLevel serverLevel)) {
            return;
        }


        /*
         * 向いている方向
         */

        Vec3 direction =
            entity.getLookAngle();

        if (direction == null) {

            direction =
                new Vec3(
                    0.0D,
                    0.0D,
                    1.0D
                );
        }


        if (
            direction.lengthSqr()
            <= 0.000001D
        ) {

            direction =
                new Vec3(
                    0.0D,
                    0.0D,
                    1.0D
                );
        }


        direction =
            direction.normalize();


        /*
         * 突進方向をこの時点で固定
         */

        saveDashDirection(
            entity,
            direction
        );


        /*
         * 予備線の開始位置
         */

        Vec3 start =
            entity.position()
                .add(
                    0.0D,
                    Math.max(
                        0.1D,
                        entity.getBbHeight()
                            * 0.5D
                    ),
                    0.0D
                );


        /*
         * =====================================================
         * 15ブロック全部表示
         * =====================================================
         *
         * 0.25ブロック刻み。
         *
         * 0.5～15.0までなので、
         * 15ブロックの最後まで炎が存在する。
         */

        for (
            double distance = 0.5D;
            distance <= DASH_DISTANCE;
            distance += 0.25D
        ) {

            Vec3 position =
                start.add(
                    direction.scale(
                        distance
                    )
                );


            /*
             * メインの炎
             */

            serverLevel.sendParticles(
                ParticleTypes.FLAME,
                position.x,
                position.y,
                position.z,
                2,
                0.08D,
                0.08D,
                0.08D,
                0.01D
            );


            /*
             * 少し下にも炎を追加
             */

            serverLevel.sendParticles(
                ParticleTypes.FLAME,
                position.x,
                position.y - 0.5D,
                position.z,
                1,
                0.05D,
                0.05D,
                0.05D,
                0.0D
            );
        }
    }


    /*
     * =========================================================
     * 突進開始
     * =========================================================
     */

    private void startDash(
        LivingEntity entity,
        int amplifier
    ) {

        if (entity == null) {
            return;
        }


        Vec3 direction =
            getDashDirection(
                entity
            );


        if (direction == null) {

            direction =
                entity.getLookAngle();
        }


        if (direction == null) {

            direction =
                new Vec3(
                    0.0D,
                    0.0D,
                    1.0D
                );
        }


        if (
            direction.lengthSqr()
            <= 0.000001D
        ) {

            direction =
                new Vec3(
                    0.0D,
                    0.0D,
                    1.0D
                );
        }


        direction =
            direction.normalize();


        saveDashDirection(
            entity,
            direction
        );


        /*
         * =====================================================
         * 突進直前に少し浮かせる
         * =====================================================
         *
         * 現在位置から0.5ブロック上へ。
         */

        entity.setPos(
            entity.getX(),
            entity.getY()
                + DASH_LIFT_HEIGHT,
            entity.getZ()
        );


        /*
         * 突進状態
         */

        entity.getPersistentData()
            .putBoolean(
                DASHING,
                true
            );


        /*
         * 突進残り10tick
         */

        entity.getPersistentData()
            .putInt(
                DASH_TICKS_REMAINING,
                DASH_TICKS
            );


        /*
         * 前回の命中記録を削除
         */

        clearHitData(
            entity
        );


        /*
         * 最初の突進速度
         */

        entity.setDeltaMovement(
            direction.scale(
                DASH_SPEED
            )
        );

        entity.hurtMarked = true;
    }


    /*
     * =========================================================
     * 突進方向保存
     * =========================================================
     */

    private void saveDashDirection(
        LivingEntity entity,
        Vec3 direction
    ) {

        if (
            entity == null
            || direction == null
        ) {
            return;
        }


        entity.getPersistentData()
            .putDouble(
                DASH_DIRECTION_X,
                direction.x
            );

        entity.getPersistentData()
            .putDouble(
                DASH_DIRECTION_Y,
                direction.y
            );

        entity.getPersistentData()
            .putDouble(
                DASH_DIRECTION_Z,
                direction.z
            );
    }


    /*
     * =========================================================
     * 突進方向取得
     * =========================================================
     */

    private Vec3 getDashDirection(
        LivingEntity entity
    ) {

        if (entity == null) {
            return null;
        }


        CompoundTag data =
            entity.getPersistentData();


        if (data == null) {
            return null;
        }


        double x =
            data.getDouble(
                DASH_DIRECTION_X
            );

        double y =
            data.getDouble(
                DASH_DIRECTION_Y
            );

        double z =
            data.getDouble(
                DASH_DIRECTION_Z
            );


        Vec3 direction =
            new Vec3(
                x,
                y,
                z
            );


        if (
            direction.lengthSqr()
            <= 0.000001D
        ) {
            return null;
        }


        return direction.normalize();
    }


    /*
     * =========================================================
     * 突進tick
     * =========================================================
     */

    private void tickDash(
        LivingEntity entity,
        int amplifier
    ) {

        if (entity == null) {
            return;
        }


        Level level =
            entity.level();

        if (level == null) {
            return;
        }


        int remaining =
            entity.getPersistentData()
                .getInt(
                    DASH_TICKS_REMAINING
                );


        if (remaining <= 0) {

            finishDash(
                entity
            );

            return;
        }


        /*
         * 突進方向
         */

        Vec3 direction =
            getDashDirection(
                entity
            );


        if (direction == null) {

            finishDash(
                entity
            );

            return;
        }


        /*
         * =====================================================
         * 突進中の移動
         * =====================================================
         */

        entity.setDeltaMovement(
            direction.scale(
                DASH_SPEED
            )
        );

        entity.hurtMarked = true;


        /*
         * =====================================================
         * 炎
         * =====================================================
         */

        spawnDashFlames(
            entity,
            direction
        );


        /*
         * =====================================================
         * 接触判定
         * =====================================================
         */

        checkDashCollision(
            entity,
            amplifier
        );


        /*
         * =====================================================
         * 残りtick
         * =====================================================
         */

        remaining--;

        entity.getPersistentData()
            .putInt(
                DASH_TICKS_REMAINING,
                remaining
            );


        /*
         * =====================================================
         * 突進終了
         * =====================================================
         */

        if (remaining <= 0) {

            finishDash(
                entity
            );
        }
    }


    /*
     * =========================================================
     * 突進中の炎
     * =========================================================
     */

    private void spawnDashFlames(
        LivingEntity entity,
        Vec3 direction
    ) {

        if (
            entity == null
            || direction == null
        ) {
            return;
        }


        Level level =
            entity.level();

        if (level == null) {
            return;
        }


        if (!(level instanceof ServerLevel serverLevel)) {
            return;
        }


        Vec3 position =
            entity.position()
                .add(
                    0.0D,
                    Math.max(
                        0.1D,
                        entity.getBbHeight()
                            * 0.5D
                    ),
                    0.0D
                );


        /*
         * 本体
         */

        serverLevel.sendParticles(
            ParticleTypes.FLAME,
            position.x,
            position.y,
            position.z,
            12,
            0.4D,
            0.4D,
            0.4D,
            0.03D
        );


        /*
         * 後方の炎の軌跡
         */

        for (int i = 1; i <= 4; i++) {

            Vec3 trail =
                position.subtract(
                    direction.scale(
                        i * 0.45D
                    )
                );


            serverLevel.sendParticles(
                ParticleTypes.FLAME,
                trail.x,
                trail.y,
                trail.z,
                3,
                0.1D,
                0.1D,
                0.1D,
                0.01D
            );
        }
    }


    /*
     * =========================================================
     * 衝突判定
     * =========================================================
     */

    private void checkDashCollision(
        LivingEntity attacker,
        int amplifier
    ) {

        if (attacker == null) {
            return;
        }


        Level level =
            attacker.level();

        if (level == null) {
            return;
        }


        AABB collisionBox =
            attacker.getBoundingBox()
                .inflate(
                    HIT_RANGE
                );


        List<LivingEntity> targets =
            level.getEntitiesOfClass(
                LivingEntity.class,
                collisionBox,
                target ->
                    target != null
                    && target != attacker
                    && target.isAlive()
            );


        if (
            targets == null
            || targets.isEmpty()
        ) {
            return;
        }


        for (
            LivingEntity target :
            targets
        ) {

            if (target == null) {
                continue;
            }


            if (!target.isAlive()) {
                continue;
            }


            /*
             * =================================================
             * 自分のTame済みエンティティ
             * =================================================
             */

            if (
                isOwnTamedEntity(
                    attacker,
                    target
                )
            ) {

                continue;
            }


            /*
             * =================================================
             * すでに命中済み
             * =================================================
             */

            if (
                hasAlreadyHit(
                    attacker,
                    target
                )
            ) {

                continue;
            }


            /*
             * =================================================
             * 現在HP
             * =================================================
             */

            float currentHealth =
                target.getHealth();


            if (currentHealth <= 0.0F) {
                continue;
            }


            /*
             * 現在HPの1/10
             */

            float damage =
                currentHealth / 10.0F;


            if (damage <= 0.0F) {
                continue;
            }


            boolean damaged;


            try {

                damaged =
                    target.hurt(
                        level.damageSources()
                            .generic(),
                        damage
                    );

            } catch (
                Exception exception
            ) {

                markAlreadyHit(
                    attacker,
                    target
                );

                continue;
            }


            /*
             * =================================================
             * STAN
             * =================================================
             */

            if (damaged) {

                if (
                    TeramodModMobEffects.STAN != null
                    && TeramodModMobEffects.STAN.get() != null
                ) {

                    target.addEffect(
                        new MobEffectInstance(
                            TeramodModMobEffects.STAN.get(),
                            STAN_DURATION,
                            Math.max(
                                0,
                                amplifier
                            ),
                            false,
                            true
                        )
                    );
                }
            }


            /*
             * 同じ対象には
             * この突進中もう一度当てない
             */

            markAlreadyHit(
                attacker,
                target
            );
        }
    }


    /*
     * =========================================================
     * 自分のTame済みエンティティ判定
     * =========================================================
     */

    private boolean isOwnTamedEntity(
        LivingEntity owner,
        LivingEntity target
    ) {

        if (
            owner == null
            || target == null
        ) {
            return false;
        }


        if (
            !(target instanceof TamableAnimal tamable)
        ) {

            return false;
        }


        if (!tamable.isTame()) {
            return false;
        }


        UUID ownerUUID =
            tamable.getOwnerUUID();


        if (ownerUUID == null) {
            return false;
        }


        UUID ownerUUID2 =
            owner.getUUID();


        if (ownerUUID2 == null) {
            return false;
        }


        return ownerUUID.equals(
            ownerUUID2
        );
    }


    /*
     * =========================================================
     * 命中済み判定
     * =========================================================
     */

    private boolean hasAlreadyHit(
        LivingEntity attacker,
        LivingEntity target
    ) {

        if (
            attacker == null
            || target == null
        ) {
            return false;
        }


        UUID uuid =
            target.getUUID();


        if (uuid == null) {
            return false;
        }


        String key =
            HIT_ENTITY_PREFIX
            + uuid.toString();


        return attacker.getPersistentData()
            .getBoolean(
                key
            );
    }


    /*
     * =========================================================
     * 命中済みにする
     * =========================================================
     */

    private void markAlreadyHit(
        LivingEntity attacker,
        LivingEntity target
    ) {

        if (
            attacker == null
            || target == null
        ) {
            return;
        }


        UUID uuid =
            target.getUUID();


        if (uuid == null) {
            return;
        }


        String key =
            HIT_ENTITY_PREFIX
            + uuid.toString();


        attacker.getPersistentData()
            .putBoolean(
                key,
                true
            );
    }


    /*
     * =========================================================
     * 命中データ削除
     * =========================================================
     */

    private void clearHitData(
        LivingEntity attacker
    ) {

        if (attacker == null) {
            return;
        }


        CompoundTag data =
            attacker.getPersistentData();


        if (data == null) {
            return;
        }


        Set<String> keys =
            new HashSet<>(
                data.getAllKeys()
            );


        for (String key : keys) {

            if (key == null) {
                continue;
            }


            if (
                key.startsWith(
                    HIT_ENTITY_PREFIX
                )
            ) {

                data.remove(
                    key
                );
            }
        }
    }


    /*
     * =========================================================
     * Tossin状態リセット
     * =========================================================
     */

    private void resetTossinState(
        LivingEntity entity
    ) {

        if (entity == null) {
            return;
        }


        CompoundTag data =
            entity.getPersistentData();


        if (data == null) {
            return;
        }


        data.putInt(
            TOSSIN_ELAPSED_TICKS,
            0
        );


        data.putBoolean(
            PREVIEW_SHOWN,
            false
        );


        data.putBoolean(
            DASHING,
            false
        );


        data.putInt(
            DASH_TICKS_REMAINING,
            0
        );


        data.remove(
            DASH_DIRECTION_X
        );

        data.remove(
            DASH_DIRECTION_Y
        );

        data.remove(
            DASH_DIRECTION_Z
        );


        clearHitData(
            entity
        );
    }


    /*
     * =========================================================
     * 突進終了
     * =========================================================
     */

    private void finishDash(
        LivingEntity entity
    ) {

        if (entity == null) {
            return;
        }


        CompoundTag data =
            entity.getPersistentData();


        if (data != null) {

            data.putBoolean(
                DASHING,
                false
            );

            data.putInt(
                DASH_TICKS_REMAINING,
                0
            );

            data.putBoolean(
                PREVIEW_SHOWN,
                false
            );

            data.putInt(
                TOSSIN_ELAPSED_TICKS,
                0
            );
        }


        /*
         * 突進停止
         */

        entity.setDeltaMovement(
            Vec3.ZERO
        );

        entity.hurtMarked = true;


        /*
         * 命中記録削除
         */

        clearHitData(
            entity
        );


        /*
         * =====================================================
         * ここで初めてTossinを解除
         * =====================================================
         */

        if (entity.hasEffect(this)) {

            entity.removeEffect(
                this
            );
        }
    }


    /*
     * =========================================================
     * 回復アイテムなし
     * =========================================================
     */

    @Override
    public List<ItemStack> getCurativeItems() {

        return new ArrayList<ItemStack>();
    }
}