
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.coms.ten.teramod.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.Registries;

import net.coms.ten.teramod.TeramodMod;

public class TeramodModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, TeramodMod.MODID);
	public static final RegistryObject<CreativeModeTab> TERA = REGISTRY.register("tera",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.teramod.tera")).icon(() -> new ItemStack(Blocks.AIR)).displayItems((parameters, tabData) -> {
				tabData.accept(TeramodModItems.KERU_BOSS_SPAWN_EGG.get());
				tabData.accept(TeramodModItems.TOKUSYU.get());
				tabData.accept(TeramodModItems.TOKUSYU_2.get());
				tabData.accept(TeramodModItems.DOROXTUPU.get());
				tabData.accept(TeramodModItems.KERUKYUUSYUU.get());
				tabData.accept(TeramodModItems.TOSSINBUKI.get());
				tabData.accept(TeramodModItems.KERUKYUIN_2.get());
				tabData.accept(TeramodModItems.SYOUKANITEM.get());
				tabData.accept(TeramodModItems.CORE_1.get());
				tabData.accept(TeramodModItems.CORE_2.get());
				tabData.accept(TeramodModItems.CORE_3.get());
				tabData.accept(TeramodModBlocks.HIRAISINS.get().asItem());
				tabData.accept(TeramodModBlocks.HAKA.get().asItem());
				tabData.accept(TeramodModItems.SYOUKANKORE.get());
			}).withSearchBar().build());
}
