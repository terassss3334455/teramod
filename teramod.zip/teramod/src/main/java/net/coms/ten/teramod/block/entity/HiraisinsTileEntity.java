package net.coms.ten.teramod.block.entity;

import software.bernie.geckolib.util.GeckoLibUtil;
import software.bernie.geckolib.core.object.PlayState;
import software.bernie.geckolib.core.animation.RawAnimation;
import software.bernie.geckolib.core.animation.AnimationState;
import software.bernie.geckolib.core.animation.AnimationController;
import software.bernie.geckolib.core.animation.AnimatableManager;
import software.bernie.geckolib.core.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.animatable.GeoBlockEntity;

import net.minecraftforge.items.wrapper.SidedInvWrapper;
import net.minecraftforge.items.IItemHandler;
import net.minecraftforge.common.util.LazyOptional;
import net.minecraftforge.common.capabilities.ForgeCapabilities;
import net.minecraftforge.common.capabilities.Capability;

import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.entity.RandomizableContainerBlockEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.inventory.ChestMenu;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.WorldlyContainer;
import net.minecraft.world.ContainerHelper;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.network.chat.Component;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.core.NonNullList;
import net.minecraft.core.Direction;
import net.minecraft.core.BlockPos;

import net.coms.ten.teramod.init.TeramodModBlockEntities;
import net.coms.ten.teramod.block.HiraisinsBlock;
import net.coms.ten.teramod.entity.HakaidanEntity;

import javax.annotation.Nullable;

import java.util.List;
import java.util.stream.IntStream;

public class HiraisinsTileEntity extends RandomizableContainerBlockEntity
        implements GeoBlockEntity, WorldlyContainer {

    private final AnimatableInstanceCache cache =
            GeckoLibUtil.createInstanceCache(this);

    private NonNullList<ItemStack> stacks =
            NonNullList.withSize(9, ItemStack.EMPTY);

    private final LazyOptional<? extends IItemHandler>[] handlers =
            SidedInvWrapper.create(this, Direction.values());

    /*
     * ==========================================
     * 避雷針のHakaidan吸引設定
     * ==========================================
     */

    // 吸引範囲
    private static final double ATTRACT_RANGE = 20.0D;

    // 吸引力
    private static final double ATTRACT_STRENGTH = 0.55D;

    // 最大吸引速度
    private static final double MAX_ATTRACT_SPEED = 2.5D;

    public HiraisinsTileEntity(
            BlockPos pos,
            BlockState state) {

        super(
                TeramodModBlockEntities.HIRAISINS.get(),
                pos,
                state
        );
    }

    /*
     * ==========================================
     * 毎tick処理
     * ==========================================
     *
     * 避雷針が設置されている間、
     * 周囲のHakaidanを強力に吸引する。
     */
    public static void tick(
            Level level,
            BlockPos pos,
            BlockState state,
            HiraisinsTileEntity blockEntity) {

        // クライアント側では処理しない
        if (level.isClientSide()) {
            return;
        }

        /*
         * 避雷針を中心に半径20ブロックを検索
         */
        AABB area = new AABB(pos).inflate(ATTRACT_RANGE);

        List<HakaidanEntity> hakaidans =
                level.getEntitiesOfClass(
                        HakaidanEntity.class,
                        area
                );

        /*
         * 見つかったHakaidanを吸引
         */
        for (HakaidanEntity hakaidan : hakaidans) {

            if (!hakaidan.isAlive()) {
                continue;
            }

            /*
             * 避雷針の中心座標
             */
            Vec3 center =
                    Vec3.atCenterOf(pos);

            /*
             * Hakaidanから避雷針へ向かう方向
             */
            Vec3 direction =
                    center.subtract(
                            hakaidan.position()
                    );

            double distance =
                    direction.length();

            /*
             * 避雷針の中心に近すぎる場合
             * 無理に速度を追加しない
             */
            if (distance < 0.05D) {
                continue;
            }

            /*
             * 範囲外なら無視
             */
            if (distance > ATTRACT_RANGE) {
                continue;
            }

            /*
             * 遠いほど強く引っ張る
             *
             * 0.5 ～ 1.5倍程度の補正
             */
            double distanceRatio =
                    distance / ATTRACT_RANGE;

            double strength =
                    ATTRACT_STRENGTH
                            * (0.5D + distanceRatio);

            /*
             * 吸引方向を正規化
             */
            Vec3 pull =
                    direction
                            .normalize()
                            .scale(strength);

            /*
             * 現在の速度
             */
            Vec3 currentVelocity =
                    hakaidan.getDeltaMovement();

            /*
             * 現在の速度を少し残しながら
             * 避雷針方向へ加速
             */
            Vec3 newVelocity =
                    currentVelocity
                            .scale(0.75D)
                            .add(pull);

            /*
             * 最大速度制限
             */
            double speed =
                    newVelocity.length();

            if (speed > MAX_ATTRACT_SPEED) {

                newVelocity =
                        newVelocity
                                .normalize()
                                .scale(MAX_ATTRACT_SPEED);
            }

            /*
             * Hakaidanへ速度を適用
             */
            hakaidan.setDeltaMovement(
                    newVelocity
            );

            /*
             * クライアント側へ速度変更を通知
             */
            hakaidan.hurtMarked = true;
        }
    }

    /*
     * ==========================================
     * 通常アニメーション
     * ==========================================
     */

    private PlayState predicate(AnimationState event) {

        String animationprocedure =
                "" + this.getBlockState()
                        .getValue(HiraisinsBlock.ANIMATION);

        if (animationprocedure.equals("0")) {

            return event.setAndContinue(
                    RawAnimation.begin()
                            .thenLoop(animationprocedure)
            );
        }

        return PlayState.STOP;
    }

    String prevAnim = "0";

    /*
     * ==========================================
     * プロシージャアニメーション
     * ==========================================
     */

    private PlayState procedurePredicate(AnimationState event) {

        String animationprocedure =
                "" + this.getBlockState()
                        .getValue(HiraisinsBlock.ANIMATION);

        if (
                !animationprocedure.equals("0")
                        && event.getController()
                        .getAnimationState()
                        == AnimationController.State.STOPPED

                        || (
                        !animationprocedure.equals(prevAnim)
                                && !animationprocedure.equals("0")
                )
        ) {

            if (!animationprocedure.equals(prevAnim)) {
                event.getController()
                        .forceAnimationReset();
            }

            event.getController().setAnimation(
                    RawAnimation.begin()
                            .thenPlay(animationprocedure)
            );

            if (
                    event.getController()
                            .getAnimationState()
                            == AnimationController.State.STOPPED
            ) {

                if (
                        this.getBlockState()
                                .getBlock()
                                .getStateDefinition()
                                .getProperty("animation")
                                instanceof IntegerProperty _integerProp
                ) {

                    level.setBlock(
                            this.getBlockPos(),
                            this.getBlockState()
                                    .setValue(
                                            _integerProp,
                                            0
                                    ),
                            3
                    );
                }

                event.getController()
                        .forceAnimationReset();
            }

        } else if (animationprocedure.equals("0")) {

            prevAnim = "0";

            return PlayState.STOP;
        }

        prevAnim = animationprocedure;

        return PlayState.CONTINUE;
    }

    /*
     * ==========================================
     * GeckoLib Controller
     * ==========================================
     */

    @Override
    public void registerControllers(
            AnimatableManager.ControllerRegistrar data) {

        data.add(
                new AnimationController<HiraisinsTileEntity>(
                        this,
                        "controller",
                        0,
                        this::predicate
                )
        );

        data.add(
                new AnimationController<HiraisinsTileEntity>(
                        this,
                        "procedurecontroller",
                        0,
                        this::procedurePredicate
                )
        );
    }

    @Override
    public AnimatableInstanceCache getAnimatableInstanceCache() {
        return this.cache;
    }

    /*
     * ==========================================
     * NBT
     * ==========================================
     */

    @Override
    public void load(CompoundTag compound) {

        super.load(compound);

        if (!this.tryLoadLootTable(compound)) {

            this.stacks =
                    NonNullList.withSize(
                            this.getContainerSize(),
                            ItemStack.EMPTY
                    );
        }

        ContainerHelper.loadAllItems(
                compound,
                this.stacks
        );
    }

    @Override
    public void saveAdditional(CompoundTag compound) {

        super.saveAdditional(compound);

        if (!this.trySaveLootTable(compound)) {

            ContainerHelper.saveAllItems(
                    compound,
                    this.stacks
            );
        }
    }

    @Override
    public ClientboundBlockEntityDataPacket getUpdatePacket() {

        return ClientboundBlockEntityDataPacket.create(this);
    }

    @Override
    public CompoundTag getUpdateTag() {

        return this.saveWithFullMetadata();
    }

    /*
     * ==========================================
     * インベントリ
     * ==========================================
     */

    @Override
    public int getContainerSize() {

        return stacks.size();
    }

    @Override
    public boolean isEmpty() {

        for (ItemStack itemstack : this.stacks) {

            if (!itemstack.isEmpty()) {
                return false;
            }
        }

        return true;
    }

    @Override
    public Component getDefaultName() {

        return Component.literal("hiraisins");
    }

    @Override
    public int getMaxStackSize() {

        return 64;
    }

    @Override
    public AbstractContainerMenu createMenu(
            int id,
            Inventory inventory) {

        return ChestMenu.threeRows(
                id,
                inventory
        );
    }

    @Override
    public Component getDisplayName() {

        return Component.literal("避破針");
    }

    @Override
    protected NonNullList<ItemStack> getItems() {

        return this.stacks;
    }

    @Override
    protected void setItems(
            NonNullList<ItemStack> stacks) {

        this.stacks = stacks;
    }

    @Override
    public boolean canPlaceItem(
            int index,
            ItemStack stack) {

        return true;
    }

    @Override
    public int[] getSlotsForFace(
            Direction side) {

        return IntStream.range(
                0,
                this.getContainerSize()
        ).toArray();
    }

    @Override
    public boolean canPlaceItemThroughFace(
            int index,
            ItemStack stack,
            @Nullable Direction direction) {

        return this.canPlaceItem(
                index,
                stack
        );
    }

    @Override
    public boolean canTakeItemThroughFace(
            int index,
            ItemStack stack,
            Direction direction) {

        return true;
    }

    /*
     * ==========================================
     * Forge Capability
     * ==========================================
     */

    @Override
    public <T> LazyOptional<T> getCapability(
            Capability<T> capability,
            @Nullable Direction facing) {

        if (
                !this.remove
                        && facing != null
                        && capability
                        == ForgeCapabilities.ITEM_HANDLER
        ) {

            return handlers[
                    facing.ordinal()
            ].cast();
        }

        return super.getCapability(
                capability,
                facing
        );
    }

    @Override
    public void setRemoved() {

        super.setRemoved();

        for (
                LazyOptional<? extends IItemHandler> handler
                : handlers
        ) {

            handler.invalidate();
        }
    }
}