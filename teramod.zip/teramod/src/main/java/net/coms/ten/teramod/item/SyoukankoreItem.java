package net.coms.ten.teramod.item;

import net.minecraft.server.level.ServerLevel;

import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;

import net.minecraft.world.entity.player.Player;

import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Rarity;

import net.minecraft.world.level.Level;

import net.coms.ten.teramod.entity.CoresyoukanEntity;
import net.coms.ten.teramod.init.TeramodModEntities;

public class SyoukankoreItem extends Item {

    public SyoukankoreItem() {

        super(
                new Item.Properties()
                        .stacksTo(64)
                        .rarity(Rarity.EPIC)
        );
    }

    @Override
    public InteractionResultHolder<ItemStack> use(
            Level level,
            Player player,
            InteractionHand hand
    ) {

        ItemStack itemstack =
                player.getItemInHand(hand);

        /*
         * サーバー側のみ実行
         */
        if (!level.isClientSide()) {

            ServerLevel serverLevel =
                    (ServerLevel) level;

            /*
             * コア召喚エンティティ生成
             */
            CoresyoukanEntity entity =
                    new CoresyoukanEntity(
                            TeramodModEntities.CORESYOUKAN.get(),
                            player.getX(),
                            player.getEyeY() - 0.2D,
                            player.getZ(),
                            serverLevel
                    );

            /*
             * 所有者
             */
            entity.setOwner(player);

            /*
             * 重力なし
             */
            entity.setNoGravity(true);

            /*
             * シンデンを探す
             */
            entity.findTargetStructure();

            /*
             * ワールドに追加
             */
            serverLevel.addFreshEntity(entity);

            /*
             * 使用時に1個消費
             *
             * クリエイティブでは消費しない
             */
            if (!player.getAbilities().instabuild) {

                itemstack.shrink(1);
            }
        }

        return InteractionResultHolder.sidedSuccess(
                itemstack,
                level.isClientSide()
        );
    }
}