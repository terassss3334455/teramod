package net.coms.ten.teramod.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.world.entity.Entity;

import net.coms.ten.teramod.TeramodMod;

public class HakaidanenteiteigasuponsitaShiProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		TeramodMod.queueServerWork(400, () -> {
			if (world instanceof Level _level && !_level.isClientSide())
				_level.explode(null, x, y, z, 15, Level.ExplosionInteraction.BLOCK);
			if (!entity.level().isClientSide())
				entity.discard();
		});
	}
}
