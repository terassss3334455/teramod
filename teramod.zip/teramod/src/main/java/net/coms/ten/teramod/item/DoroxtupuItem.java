
package net.coms.ten.teramod.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class DoroxtupuItem extends Item {
	public DoroxtupuItem() {
		super(new Item.Properties().stacksTo(64).rarity(Rarity.EPIC));
	}
}
