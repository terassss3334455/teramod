package net.coms.ten.teramod.procedures;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffect;

import net.minecraftforge.event.entity.living.LivingHurtEvent;

public class YuukoujyouziProcedure {

    public static void execute(
            LivingEntity entity,
            LivingHurtEvent event,
            MobEffect stanEffect) {

        if (entity == null || event == null || stanEffect == null) {
            return;
        }

        MobEffectInstance effect =
                entity.getEffect(stanEffect);

        if (effect == null) {
            return;
        }

        // エフェクトレベルを取得
        // レベルI  = amplifier 0
        // レベルII = amplifier 1
        // レベルIII = amplifier 2
        int amplifier = effect.getAmplifier();

        // レベルI  → ×2
        // レベルII → ×3
        // レベルIII → ×4
        // レベルIV → ×5
        float multiplier = amplifier + 2.0F;

        event.setAmount(
            event.getAmount() * multiplier
        );
    }
}