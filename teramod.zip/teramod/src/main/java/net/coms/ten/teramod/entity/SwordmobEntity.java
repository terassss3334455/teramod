package net.coms.ten.teramod.entity;

import software.bernie.geckolib.util.GeckoLibUtil;
import software.bernie.geckolib.core.object.PlayState;
import software.bernie.geckolib.core.animation.RawAnimation;
import software.bernie.geckolib.core.animation.AnimationState;
import software.bernie.geckolib.core.animation.AnimationController;
import software.bernie.geckolib.core.animation.AnimatableManager;
import software.bernie.geckolib.core.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.animatable.GeoEntity;

import net.coms.ten.teramod.init.TeramodModEntities;
import net.coms.ten.teramod.init.TeramodModMobEffects;
import net.coms.ten.teramod.potion.SwordmasicMobEffect;

import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.network.PlayMessages;
import net.minecraftforge.network.NetworkHooks;

import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.Level;

import net.minecraft.world.entity.monster.Monster;

import net.minecraft.world.entity.ai.navigation.PathNavigation;
import net.minecraft.world.entity.ai.navigation.FlyingPathNavigation;

import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.FloatGoal;

import net.minecraft.world.entity.ai.control.FlyingMoveControl;

import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;

import net.minecraft.world.entity.SpawnPlacements;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.entity.MobType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EntityDimensions;

import net.minecraft.world.entity.player.Player;

import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;

import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.damagesource.DamageSource;

import net.minecraft.world.Difficulty;

import net.minecraft.sounds.SoundEvent;

import net.minecraft.resources.ResourceLocation;

import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.EntityDataAccessor;

import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.Packet;

import net.minecraft.nbt.CompoundTag;

import net.minecraft.core.BlockPos;

import net.minecraft.world.InteractionHand;

import java.util.UUID;


/**
 * Swordmasicによって召喚されるSwordmob
 */
public class SwordmobEntity extends Monster implements GeoEntity {

    /*
     * =========================================
     * EntityData
     * =========================================
     */

    public static final EntityDataAccessor<Boolean> SHOOT =
            SynchedEntityData.defineId(
                    SwordmobEntity.class,
                    EntityDataSerializers.BOOLEAN
            );

    public static final EntityDataAccessor<String> ANIMATION =
            SynchedEntityData.defineId(
                    SwordmobEntity.class,
                    EntityDataSerializers.STRING
            );

    public static final EntityDataAccessor<String> TEXTURE =
            SynchedEntityData.defineId(
                    SwordmobEntity.class,
                    EntityDataSerializers.STRING
            );


    /*
     * =========================================
     * GeckoLib
     * =========================================
     */

    private final AnimatableInstanceCache cache =
            GeckoLibUtil.createInstanceCache(this);

    private boolean swinging;

    private long lastSwing;

    public String animationprocedure = "empty";


    /*
     * =========================================
     * Swordmasic
     * =========================================
     */

    private UUID ownerUUID;

    private int swordmasicAmplifier = 0;

    private int attackCooldown = 0;


    /*
     * =========================================
     * 高速飛行設定
     * =========================================
     */

    /*
     * 飼い主への追従速度
     */
    private static final double FOLLOW_SPEED = 3.0D;

    /*
     * 敵への追跡速度
     */
    private static final double COMBAT_SPEED = 3.5D;

    /*
     * 飼い主からこの距離以上離れたら追従
     */
    private static final double FOLLOW_DISTANCE = 4.0D;


    /*
     * =========================================
     * 護衛モード
     * =========================================
     */

    /*
     * 飼い主のHPが50%以下で護衛モード
     */
    private static final double GUARD_HEALTH_RATIO = 0.5D;

    /*
     * 飼い主から8ブロック以上離れたら戻る
     */
    private static final double GUARD_DISTANCE = 8.0D;

    /*
     * 8ブロック以内なら再生
     */
    private static final double REGEN_DISTANCE = 8.0D;


    /*
     * =========================================
     * Constructor
     * =========================================
     */

    public SwordmobEntity(
            PlayMessages.SpawnEntity packet,
            Level world
    ) {

        this(
                TeramodModEntities.SWORDMOB.get(),
                world
        );
    }


    public SwordmobEntity(
            EntityType<SwordmobEntity> type,
            Level world
    ) {

        super(type, world);

        xpReward = 0;

        setNoAi(false);

        setMaxUpStep(0.6f);


        /*
         * 高速飛行用
         */
        this.moveControl =
                new FlyingMoveControl(
                        this,
                        20,
                        true
                );


        /*
         * 壁抜け
         */
        this.noPhysics = true;
    }


    /*
     * =========================================
     * EntityData
     * =========================================
     */

    @Override
    protected void defineSynchedData() {

        super.defineSynchedData();

        this.entityData.define(
                SHOOT,
                false
        );

        this.entityData.define(
                ANIMATION,
                "undefined"
        );

        this.entityData.define(
                TEXTURE,
                "swordtexture"
        );
    }


    /*
     * =========================================
     * Texture
     * =========================================
     */

    public void setTexture(
            String texture
    ) {

        this.entityData.set(
                TEXTURE,
                texture
        );
    }


    public String getTexture() {

        return this.entityData.get(
                TEXTURE
        );
    }


    /*
     * =========================================
     * Network
     * =========================================
     */

    @Override
    public Packet<ClientGamePacketListener> getAddEntityPacket() {

        return NetworkHooks.getEntitySpawningPacket(
                this
        );
    }


    /*
     * =========================================
     * Navigation
     * =========================================
     */

    @Override
    protected PathNavigation createNavigation(
            Level world
    ) {

        return new FlyingPathNavigation(
                this,
                world
        );
    }


    /*
     * =========================================
     * AI Goals
     * =========================================
     */

    @Override
    protected void registerGoals() {

        super.registerGoals();

        this.targetSelector.addGoal(
                1,
                new HurtByTargetGoal(this)
        );

        this.goalSelector.addGoal(
                5,
                new RandomLookAroundGoal(this)
        );

        this.goalSelector.addGoal(
                6,
                new FloatGoal(this)
        );
    }


    /*
     * =========================================
     * Owner
     * =========================================
     */

    public void setOwnerUUID(
            UUID uuid
    ) {

        this.ownerUUID = uuid;
    }


    public UUID getOwnerUUID() {

        return this.ownerUUID;
    }


    public LivingEntity getSwordmasicOwner() {

        if (ownerUUID == null) {

            return null;
        }


        if (
                !(level()
                        instanceof net.minecraft.server.level.ServerLevel serverLevel)
        ) {

            return null;
        }


        Entity entity =
                serverLevel.getEntity(
                        ownerUUID
                );


        if (entity instanceof LivingEntity living) {

            return living;
        }


        return null;
    }


    /*
     * =========================================
     * Swordmasic Level
     * =========================================
     */

    public void setSwordmasicAmplifier(
            int amplifier
    ) {

        this.swordmasicAmplifier =
                amplifier;
    }


    public int getSwordmasicAmplifier() {

        return this.swordmasicAmplifier;
    }


    /*
     * =========================================
     * AI
     * =========================================
     */

    @Override
    public void aiStep() {

        super.aiStep();


        /*
         * 常時飛行
         */
        this.setNoGravity(true);


        /*
         * 壁抜け
         */
        this.noPhysics = true;


        /*
         * クライアントでは処理しない
         */
        if (level().isClientSide()) {

            return;
        }


        /*
         * 攻撃クールタイム
         */
        if (attackCooldown > 0) {

            attackCooldown--;
        }


        /*
         * 飼い主取得
         */
        LivingEntity owner =
                getSwordmasicOwner();


        /*
         * 飼い主がいなくなったら消滅
         */
        if (owner == null) {

            this.discard();

            return;
        }


        /*
         * Swordmasic確認
         */
        MobEffectInstance effect =
                owner.getEffect(
                        TeramodModMobEffects.SWORDMASIC.get()
                );


        /*
         * Swordmasicが消えたら消滅
         */
        if (effect == null) {

            this.discard();

            return;
        }


        /*
         * エフェクトレベル
         */
        int amplifier =
                effect.getAmplifier();


        this.swordmasicAmplifier =
                amplifier;


        /*
         * =====================================
         * ステータス更新
         * =====================================
         */

        double maxHealth =
                SwordmasicMobEffect.calculateHealth(
                        amplifier
                );


        double attackDamage =
                SwordmasicMobEffect.calculateAttack(
                        amplifier
                );


        if (
                this.getAttribute(
                        Attributes.MAX_HEALTH
                ) != null
        ) {

            this.getAttribute(
                    Attributes.MAX_HEALTH
            ).setBaseValue(
                    maxHealth
            );
        }


        if (
                this.getAttribute(
                        Attributes.ATTACK_DAMAGE
                ) != null
        ) {

            this.getAttribute(
                    Attributes.ATTACK_DAMAGE
            ).setBaseValue(
                    attackDamage
            );
        }


        /*
         * =====================================
         * 護衛モード判定
         * =====================================
         */

        boolean guardMode =
                owner.getHealth()
                        <= owner.getMaxHealth()
                        * GUARD_HEALTH_RATIO;


        /*
         * =====================================
         * ターゲット取得
         * =====================================
         */

        LivingEntity target =
                findSwordmasicTarget(
                        owner
                );


        if (target != null) {

            this.setTarget(
                    target
            );

        } else {

            this.setTarget(null);
        }


        /*
         * =====================================
         * 行動
         * =====================================
         */

        if (guardMode) {

            handleGuardMode(
                    owner
            );

        } else {

            handleNormalCombat(
                    owner
            );
        }


        /*
         * =====================================
         * 再生
         * =====================================
         */

        if (
                distanceTo(owner)
                        <= REGEN_DISTANCE
        ) {

            giveRegeneration(
                    owner
            );

            giveRegeneration(
                    this
            );
        }
    }


    /*
     * =========================================
     * 通常モード
     * =========================================
     */

    private void handleNormalCombat(
            LivingEntity owner
    ) {

        LivingEntity target =
                this.getTarget();


        /*
         * ターゲットなし
         */
        if (
                target == null
                        ||
                !target.isAlive()
        ) {

            this.setTarget(null);


            /*
             * 飼い主から離れたら高速追従
             */
            if (
                    this.distanceTo(owner)
                            > FOLLOW_DISTANCE
            ) {

                moveDirectlyTo(
                        owner,
                        FOLLOW_SPEED
                );

            } else {

                this.getNavigation().stop();

                this.moveControl
                        .setWantedPosition(
                                this.getX(),
                                this.getY(),
                                this.getZ(),
                                0.0D
                        );
            }


            return;
        }


        /*
         * 敵へ高速突撃
         */
        moveDirectlyTo(
                target,
                COMBAT_SPEED
        );


        /*
         * 攻撃
         */
        attackTargetIfPossible(
                target
        );
    }


    /*
     * =========================================
     * 直接飛行
     * =========================================
     */

    private void moveDirectlyTo(
            LivingEntity target,
            double speed
    ) {

        double targetX =
                target.getX();


        double targetY =
                target.getY()
                        + target.getBbHeight()
                        * 0.5D;


        double targetZ =
                target.getZ();


        /*
         * Pathfindingを使わず直接移動
         */
        this.moveControl.setWantedPosition(
                targetX,
                targetY,
                targetZ,
                speed
        );
    }


    /*
     * =========================================
     * 護衛モード
     * =========================================
     */

    private void handleGuardMode(
            LivingEntity owner
    ) {

        /*
         * 飼い主から離れすぎたら戻る
         */
        if (
                this.distanceTo(owner)
                        > GUARD_DISTANCE
        ) {

            moveDirectlyTo(
                    owner,
                    FOLLOW_SPEED
            );

            return;
        }


        /*
         * 飼い主の近くではその場で待機
         */
        this.getNavigation().stop();

        this.moveControl
                .setWantedPosition(
                        this.getX(),
                        this.getY(),
                        this.getZ(),
                        0.0D
                );


        /*
         * ターゲット取得
         */
        LivingEntity target =
                this.getTarget();


        if (
                target != null
                        &&
                target.isAlive()
        ) {

            /*
             * 護衛中は12ブロック以内のみ攻撃
             */
            if (
                    this.distanceToSqr(target)
                            <= 12.0D * 12.0D
            ) {

                attackTargetIfPossible(
                        target
                );

            } else {

                this.setTarget(null);
            }
        }
    }


    /*
     * =========================================
     * 攻撃
     * =========================================
     */

    private void attackTargetIfPossible(
            LivingEntity target
    ) {

        if (attackCooldown > 0) {

            return;
        }


        double reach =
                this.getBbWidth()
                        + target.getBbWidth()
                        + 1.5D;


        if (
                this.distanceToSqr(target)
                        <= reach * reach
        ) {

            this.doHurtTarget(
                    target
            );


            this.swing(
                    InteractionHand.MAIN_HAND
            );


            attackCooldown = 20;
        }
    }


    /*
     * =========================================
     * ターゲット検索
     * =========================================
     *
     * プレイヤーでもMobでも同じ処理。
     *
     * 1. 飼い主が攻撃した相手
     * 2. 飼い主を攻撃した相手
     * 3. Mobの現在ターゲット
     */

    private LivingEntity findSwordmasicTarget(
            LivingEntity owner
    ) {

        /*
         * =====================================
         * 飼い主が攻撃した相手
         * =====================================
         */

        LivingEntity lastHurt =
                owner.getLastHurtMob();


        /*
         * =====================================
         * 飼い主を攻撃した相手
         * =====================================
         */

        LivingEntity attacker =
                owner.getLastHurtByMob();


        /*
         * =====================================
         * 両方存在する場合
         * =====================================
         *
         * Swordmobごとに分散
         *
         * 偶数ID
         * → 飼い主が攻撃した相手
         *
         * 奇数ID
         * → 飼い主を攻撃した相手
         */

        if (
                isValidTarget(
                        lastHurt,
                        owner
                )
                        &&
                isValidTarget(
                        attacker,
                        owner
                )
        ) {

            if (
                    (this.getId() & 1) == 0
            ) {

                return lastHurt;

            } else {

                return attacker;
            }
        }


        /*
         * =====================================
         * 飼い主が攻撃した相手
         * =====================================
         */

        if (
                isValidTarget(
                        lastHurt,
                        owner
                )
        ) {

            return lastHurt;
        }


        /*
         * =====================================
         * 飼い主を攻撃した相手
         * =====================================
         */

        if (
                isValidTarget(
                        attacker,
                        owner
                )
        ) {

            return attacker;
        }


        /*
         * =====================================
         * Mob固有のターゲット
         * =====================================
         *
         * 上記がない場合のみ使用。
         */

        if (owner instanceof Mob mob) {

            LivingEntity target =
                    mob.getTarget();


            if (
                    isValidTarget(
                            target,
                            owner
                    )
            ) {

                return target;
            }
        }


        return null;
    }


    /*
     * =========================================
     * ターゲット有効判定
     * =========================================
     */

    private boolean isValidTarget(
            LivingEntity target,
            LivingEntity owner
    ) {

        /*
         * 存在しない
         */
        if (target == null) {

            return false;
        }


        /*
         * 死亡済み
         */
        if (!target.isAlive()) {

            return false;
        }


        /*
         * 飼い主自身
         */
        if (target == owner) {

            return false;
        }


        /*
         * 同じ飼い主のSwordmob
         */
        if (
                target instanceof SwordmobEntity swordMob
        ) {

            if (
                    ownerUUID != null
                            &&
                    ownerUUID.equals(
                            swordMob.getOwnerUUID()
                    )
            ) {

                return false;
            }
        }


        return true;
    }


    /*
     * =========================================
     * 再生
     * =========================================
     */

    private void giveRegeneration(
            LivingEntity entity
    ) {

        entity.addEffect(
                new MobEffectInstance(
                        MobEffects.REGENERATION,
                        40,
                        0,
                        true,
                        false,
                        true
                )
        );
    }


    /*
     * =========================================
     * MobType
     * =========================================
     */

    @Override
    public MobType getMobType() {

        return MobType.UNDEFINED;
    }


    /*
     * =========================================
     * Sound
     * =========================================
     */

    @Override
    public SoundEvent getHurtSound(
            DamageSource ds
    ) {

        return ForgeRegistries.SOUND_EVENTS.getValue(
                new ResourceLocation(
                        "entity.generic.hurt"
                )
        );
    }


    @Override
    public SoundEvent getDeathSound() {

        return ForgeRegistries.SOUND_EVENTS.getValue(
                new ResourceLocation(
                        "entity.generic.death"
                )
        );
    }


    /*
     * =========================================
     * 落下ダメージ無効
     * =========================================
     */

    @Override
    public boolean causeFallDamage(
            float l,
            float d,
            DamageSource source
    ) {

        return false;
    }


    /*
     * =========================================
     * Damage
     * =========================================
     */

    @Override
    public boolean hurt(
            DamageSource source,
            float amount
    ) {

        /*
         * 爆発ダメージ無効
         */
        if (
                source.is(
                        DamageTypes.EXPLOSION
                )
        ) {

            return false;
        }


        return super.hurt(
                source,
                amount
        );
    }


    /*
     * =========================================
     * Save
     * =========================================
     */

    @Override
    public void addAdditionalSaveData(
            CompoundTag compound
    ) {

        super.addAdditionalSaveData(
                compound
        );


        compound.putString(
                "Texture",
                this.getTexture()
        );


        if (ownerUUID != null) {

            compound.putUUID(
                    "SwordmasicOwner",
                    ownerUUID
            );
        }


        compound.putInt(
                "SwordmasicAmplifier",
                swordmasicAmplifier
        );
    }


    /*
     * =========================================
     * Load
     * =========================================
     */

    @Override
    public void readAdditionalSaveData(
            CompoundTag compound
    ) {

        super.readAdditionalSaveData(
                compound
        );


        if (
                compound.contains(
                        "Texture"
                )
        ) {

            this.setTexture(
                    compound.getString(
                            "Texture"
                    )
            );
        }


        if (
                compound.hasUUID(
                        "SwordmasicOwner"
                )
        ) {

            this.ownerUUID =
                    compound.getUUID(
                            "SwordmasicOwner"
                    );
        }


        if (
                compound.contains(
                        "SwordmasicAmplifier"
                )
        ) {

            this.swordmasicAmplifier =
                    compound.getInt(
                            "SwordmasicAmplifier"
                    );
        }
    }


    /*
     * =========================================
     * Base Tick
     * =========================================
     */

    @Override
    public void baseTick() {

        super.baseTick();

        this.refreshDimensions();

        /*
         * 壁抜け
         */
        this.noPhysics = true;

        /*
         * 重力なし
         */
        this.setNoGravity(true);
    }


    /*
     * =========================================
     * Dimensions
     * =========================================
     */

    @Override
    public EntityDimensions getDimensions(
            Pose pose
    ) {

        return super.getDimensions(
                pose
        ).scale(
                1.0F
        );
    }


    /*
     * =========================================
     * Fall Damage
     * =========================================
     */

    @Override
    protected void checkFallDamage(
            double y,
            boolean onGroundIn,
            BlockState state,
            BlockPos pos
    ) {
    }


    /*
     * =========================================
     * Gravity
     * =========================================
     */

    @Override
    public void setNoGravity(
            boolean ignored
    ) {

        super.setNoGravity(true);
    }


    /*
     * =========================================
     * Spawn
     * =========================================
     */

    public static void init() {

        SpawnPlacements.register(
                TeramodModEntities.SWORDMOB.get(),
                SpawnPlacements.Type.ON_GROUND,
                Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,
                (
                        entityType,
                        world,
                        reason,
                        pos,
                        random
                ) ->
                        (
                                world.getDifficulty()
                                        != Difficulty.PEACEFUL

                                        &&

                                Monster.isDarkEnoughToSpawn(
                                        world,
                                        pos,
                                        random
                                )

                                        &&

                                Mob.checkMobSpawnRules(
                                        entityType,
                                        world,
                                        reason,
                                        pos,
                                        random
                                )
                        )
        );
    }


    /*
     * =========================================
     * Attributes
     * =========================================
     */

    public static AttributeSupplier.Builder createAttributes() {

        AttributeSupplier.Builder builder =
                Mob.createMobAttributes();


        builder = builder.add(
                Attributes.MOVEMENT_SPEED,
                0.3
        );


        builder = builder.add(
                Attributes.MAX_HEALTH,
                40
        );


        builder = builder.add(
                Attributes.ARMOR,
                8
        );


        builder = builder.add(
                Attributes.ATTACK_DAMAGE,
                15
        );


        builder = builder.add(
                Attributes.FOLLOW_RANGE,
                100
        );


        /*
         * 飛行速度
         */
        builder = builder.add(
                Attributes.FLYING_SPEED,
                1.5
        );


        return builder;
    }


    /*
     * =========================================
     * GeckoLib Animation
     * =========================================
     */

    private PlayState movementPredicate(
            AnimationState event
    ) {

        if (
                this.animationprocedure.equals(
                        "empty"
                )
        ) {

            return event.setAndContinue(
                    RawAnimation.begin()
                            .thenLoop("idle")
            );
        }


        return PlayState.STOP;
    }


    private PlayState attackingPredicate(
            AnimationState event
    ) {

        double d1 =
                this.getX()
                        - this.xOld;


        double d0 =
                this.getZ()
                        - this.zOld;


        float velocity =
                (float) Math.sqrt(
                        d1 * d1
                                +
                        d0 * d0
                );


        if (
                getAttackAnim(
                        event.getPartialTick()
                ) > 0f

                        &&

                !this.swinging
        ) {

            this.swinging = true;

            this.lastSwing =
                    level().getGameTime();
        }


        if (
                this.swinging

                        &&

                this.lastSwing + 7L
                        <= level().getGameTime()
        ) {

            this.swinging = false;
        }


        if (
                this.swinging

                        &&

                event.getController()
                        .getAnimationState()
                        ==
                        AnimationController.State.STOPPED
        ) {

            event.getController()
                    .forceAnimationReset();


            return event.setAndContinue(
                    RawAnimation.begin()
                            .thenPlay("attack")
            );
        }


        return PlayState.CONTINUE;
    }


    String prevAnim = "empty";


    private PlayState procedurePredicate(
            AnimationState event
    ) {

        if (
                !animationprocedure.equals(
                        "empty"
                )

                        &&

                event.getController()
                        .getAnimationState()
                        ==
                        AnimationController.State.STOPPED

                        ||

                (
                        !this.animationprocedure
                                .equals(prevAnim)

                                &&

                        !this.animationprocedure
                                .equals("empty")
                )
        ) {

            if (
                    !this.animationprocedure
                            .equals(prevAnim)
            ) {

                event.getController()
                        .forceAnimationReset();
            }


            event.getController()
                    .setAnimation(
                            RawAnimation.begin()
                                    .thenPlay(
                                            this.animationprocedure
                                    )
                    );


            if (
                    event.getController()
                            .getAnimationState()
                            ==
                            AnimationController.State.STOPPED
            ) {

                this.animationprocedure =
                        "empty";


                event.getController()
                        .forceAnimationReset();
            }

        } else if (
                animationprocedure.equals(
                        "empty"
                )
        ) {

            prevAnim = "empty";

            return PlayState.STOP;
        }


        prevAnim =
                this.animationprocedure;


        return PlayState.CONTINUE;
    }


    /*
     * =========================================
     * Death
     * =========================================
     */

    @Override
    protected void tickDeath() {

        ++this.deathTime;


        if (
                this.deathTime == 20
        ) {

            this.remove(
                    SwordmobEntity.RemovalReason.KILLED
            );


            this.dropExperience();
        }
    }


    /*
     * =========================================
     * Animation Data
     * =========================================
     */

    public String getSyncedAnimation() {

        return this.entityData.get(
                ANIMATION
        );
    }


    public void setAnimation(
            String animation
    ) {

        this.entityData.set(
                ANIMATION,
                animation
        );
    }


    /*
     * =========================================
     * GeckoLib Controllers
     * =========================================
     */

    @Override
    public void registerControllers(
            AnimatableManager.ControllerRegistrar data
    ) {

        data.add(
                new AnimationController<>(
                        this,
                        "movement",
                        4,
                        this::movementPredicate
                )
        );


        data.add(
                new AnimationController<>(
                        this,
                        "attacking",
                        4,
                        this::attackingPredicate
                )
        );


        data.add(
                new AnimationController<>(
                        this,
                        "procedure",
                        4,
                        this::procedurePredicate
                )
        );
    }


    /*
     * =========================================
     * GeckoLib Cache
     * =========================================
     */

    @Override
    public AnimatableInstanceCache getAnimatableInstanceCache() {

        return this.cache;
    }
}