
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.coms.ten.teramod.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.common.ForgeSpawnEggItem;

import net.minecraft.world.item.Item;

import net.coms.ten.teramod.item.TossinbukiItem;
import net.coms.ten.teramod.item.TokusyuItem;
import net.coms.ten.teramod.item.Tokusyu2Item;
import net.coms.ten.teramod.item.SyoukankoreItem;
import net.coms.ten.teramod.item.SyoukanitemItem;
import net.coms.ten.teramod.item.KerukyuusyuuItem;
import net.coms.ten.teramod.item.Kerukyuin2Item;
import net.coms.ten.teramod.item.DoroxtupuItem;
import net.coms.ten.teramod.item.Core3Item;
import net.coms.ten.teramod.item.Core2Item;
import net.coms.ten.teramod.item.Core1Item;
import net.coms.ten.teramod.block.display.HiraisinsDisplayItem;
import net.coms.ten.teramod.block.display.HakaDisplayItem;
import net.coms.ten.teramod.TeramodMod;

public class TeramodModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, TeramodMod.MODID);
	public static final RegistryObject<Item> KERU_BOSS_SPAWN_EGG = REGISTRY.register("keru_boss_spawn_egg", () -> new ForgeSpawnEggItem(TeramodModEntities.KERU_BOSS, -1, -1, new Item.Properties()));
	public static final RegistryObject<Item> HAKAIDAN_SPAWN_EGG = REGISTRY.register("hakaidan_spawn_egg", () -> new ForgeSpawnEggItem(TeramodModEntities.HAKAIDAN, -1, -1, new Item.Properties()));
	public static final RegistryObject<Item> TOKUSYU = REGISTRY.register("tokusyu", () -> new TokusyuItem());
	public static final RegistryObject<Item> TOKUSYU_2 = REGISTRY.register("tokusyu_2", () -> new Tokusyu2Item());
	public static final RegistryObject<Item> SWORDMOB_SPAWN_EGG = REGISTRY.register("swordmob_spawn_egg", () -> new ForgeSpawnEggItem(TeramodModEntities.SWORDMOB, -1, -1, new Item.Properties()));
	public static final RegistryObject<Item> DOROXTUPU = REGISTRY.register("doroxtupu", () -> new DoroxtupuItem());
	public static final RegistryObject<Item> KERUKYUUSYUU = REGISTRY.register("kerukyuusyuu", () -> new KerukyuusyuuItem());
	public static final RegistryObject<Item> TOSSINBUKI = REGISTRY.register("tossinbuki", () -> new TossinbukiItem());
	public static final RegistryObject<Item> KERUKYUIN_2 = REGISTRY.register("kerukyuin_2", () -> new Kerukyuin2Item());
	public static final RegistryObject<Item> SYOUKANITEM = REGISTRY.register("syoukanitem", () -> new SyoukanitemItem());
	public static final RegistryObject<Item> CORE_1 = REGISTRY.register("core_1", () -> new Core1Item());
	public static final RegistryObject<Item> CORE_2 = REGISTRY.register("core_2", () -> new Core2Item());
	public static final RegistryObject<Item> CORE_3 = REGISTRY.register("core_3", () -> new Core3Item());
	public static final RegistryObject<Item> HIRAISINS = REGISTRY.register(TeramodModBlocks.HIRAISINS.getId().getPath(), () -> new HiraisinsDisplayItem(TeramodModBlocks.HIRAISINS.get(), new Item.Properties()));
	public static final RegistryObject<Item> HAKA = REGISTRY.register(TeramodModBlocks.HAKA.getId().getPath(), () -> new HakaDisplayItem(TeramodModBlocks.HAKA.get(), new Item.Properties()));
	public static final RegistryObject<Item> SYOUKANKORE = REGISTRY.register("syoukankore", () -> new SyoukankoreItem());
	// Start of user code block custom items
	// End of user code block custom items
}
