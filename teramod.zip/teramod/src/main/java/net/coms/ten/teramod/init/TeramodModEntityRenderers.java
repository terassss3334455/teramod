
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.coms.ten.teramod.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.client.renderer.entity.ThrownItemRenderer;

import net.coms.ten.teramod.client.renderer.SwordmobRenderer;
import net.coms.ten.teramod.client.renderer.KeruBOSSRenderer;
import net.coms.ten.teramod.client.renderer.HakaidanRenderer;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class TeramodModEntityRenderers {
	@SubscribeEvent
	public static void registerEntityRenderers(EntityRenderersEvent.RegisterRenderers event) {
		event.registerEntityRenderer(TeramodModEntities.KERU_BOSS.get(), KeruBOSSRenderer::new);
		event.registerEntityRenderer(TeramodModEntities.HAKAIDAN.get(), HakaidanRenderer::new);
		event.registerEntityRenderer(TeramodModEntities.SWORDMOB.get(), SwordmobRenderer::new);
		event.registerEntityRenderer(TeramodModEntities.CORESYOUKAN.get(), ThrownItemRenderer::new);
	}
}
