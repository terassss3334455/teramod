package net.coms.ten.teramod.procedures;

import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.Mob;

public class StanposiyonXiaoGuogaQieretaShiProcedure {

    public static void execute(Entity entity) {
        if (entity instanceof Mob mob) {
            mob.setNoAi(false);
        }
    }
}