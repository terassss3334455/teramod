
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.coms.ten.teramod.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;

import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Entity;

import net.coms.ten.teramod.entity.SwordmobEntity;
import net.coms.ten.teramod.entity.KeruBOSSEntity;
import net.coms.ten.teramod.entity.HakaidanEntity;
import net.coms.ten.teramod.entity.CoresyoukanEntity;
import net.coms.ten.teramod.TeramodMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class TeramodModEntities {
	public static final DeferredRegister<EntityType<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, TeramodMod.MODID);
	public static final RegistryObject<EntityType<KeruBOSSEntity>> KERU_BOSS = register("keru_boss",
			EntityType.Builder.<KeruBOSSEntity>of(KeruBOSSEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(200).setUpdateInterval(3).setCustomClientFactory(KeruBOSSEntity::new).fireImmune().sized(1.5f, 1f));
	public static final RegistryObject<EntityType<HakaidanEntity>> HAKAIDAN = register("hakaidan",
			EntityType.Builder.<HakaidanEntity>of(HakaidanEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(50).setUpdateInterval(3).setCustomClientFactory(HakaidanEntity::new)

					.sized(0.6f, 0.9f));
	public static final RegistryObject<EntityType<SwordmobEntity>> SWORDMOB = register("swordmob",
			EntityType.Builder.<SwordmobEntity>of(SwordmobEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(100).setUpdateInterval(3).setCustomClientFactory(SwordmobEntity::new)

					.sized(0.3f, 0.2f));
	public static final RegistryObject<EntityType<CoresyoukanEntity>> CORESYOUKAN = register("coresyoukan",
			EntityType.Builder.<CoresyoukanEntity>of(CoresyoukanEntity::new, MobCategory.MISC).setCustomClientFactory(CoresyoukanEntity::new).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));

	// Start of user code block custom entities
	// End of user code block custom entities
	private static <T extends Entity> RegistryObject<EntityType<T>> register(String registryname, EntityType.Builder<T> entityTypeBuilder) {
		return REGISTRY.register(registryname, () -> (EntityType<T>) entityTypeBuilder.build(registryname));
	}

	@SubscribeEvent
	public static void init(FMLCommonSetupEvent event) {
		event.enqueueWork(() -> {
			KeruBOSSEntity.init();
			HakaidanEntity.init();
			SwordmobEntity.init();
		});
	}

	@SubscribeEvent
	public static void registerAttributes(EntityAttributeCreationEvent event) {
		event.put(KERU_BOSS.get(), KeruBOSSEntity.createAttributes().build());
		event.put(HAKAIDAN.get(), HakaidanEntity.createAttributes().build());
		event.put(SWORDMOB.get(), SwordmobEntity.createAttributes().build());
	}
}
