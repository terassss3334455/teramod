package net.coms.ten.teramod.entity.model;

import software.bernie.geckolib.model.GeoModel;

import net.coms.ten.teramod.entity.HakaidanEntity;

import net.minecraft.resources.ResourceLocation;

public class HakaidanModel extends GeoModel<HakaidanEntity> {
	@Override
	public ResourceLocation getAnimationResource(HakaidanEntity entity) {
		return new ResourceLocation("teramod", "animations/tobihakai.animation.json");
	}

	@Override
	public ResourceLocation getModelResource(HakaidanEntity entity) {
		return new ResourceLocation("teramod", "geo/tobihakai.geo.json");
	}

	@Override
	public ResourceLocation getTextureResource(HakaidanEntity entity) {
		return new ResourceLocation("teramod", "textures/entities/" + entity.getTexture() + ".png");
	}

}
