package net.coms.ten.teramod.block.renderer;

import software.bernie.geckolib.renderer.GeoItemRenderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.MultiBufferSource;

import net.coms.ten.teramod.block.model.HiraisinsDisplayModel;
import net.coms.ten.teramod.block.display.HiraisinsDisplayItem;

public class HiraisinsDisplayItemRenderer extends GeoItemRenderer<HiraisinsDisplayItem> {
	public HiraisinsDisplayItemRenderer() {
		super(new HiraisinsDisplayModel());
	}

	@Override
	public RenderType getRenderType(HiraisinsDisplayItem animatable, ResourceLocation texture, MultiBufferSource bufferSource, float partialTick) {
		return RenderType.entityTranslucent(getTextureLocation(animatable));
	}
}
