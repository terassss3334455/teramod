package net.coms.ten.teramod.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.util.RandomSource;
import net.minecraft.util.Mth;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.BlockPos;

import net.coms.ten.teramod.init.TeramodModMobEffects;
import net.coms.ten.teramod.init.TeramodModEntities;
import net.coms.ten.teramod.TeramodMod;

public class KeruBOSSenteiteinotitukuGengXinShiProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		double r = 0;
		if (!(entity == null)) {
			if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
				_entity.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 40, 0, false, false));
		}
		if (entity.getPersistentData().getDouble("keruon") == 0) {
			entity.getPersistentData().putDouble("kerutime", (entity.getPersistentData().getDouble("kerutime") + 1));
			if (entity.getPersistentData().getDouble("kerutime") >= 300) {
				r = Mth.nextInt(RandomSource.create(), 1, 5);
				if (r == 1) {
					if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
						_entity.addEffect(new MobEffectInstance(TeramodModMobEffects.SWORDMASIC.get(), 1200, Mth.nextInt(RandomSource.create(), 0, 5), true, true));
					entity.getPersistentData().putDouble("kerutime", 0);
				}
				if (r == 2) {
					for (int index0 = 0; index0 < 30; index0++) {
						if (world instanceof ServerLevel _level) {
							Entity entityToSpawn = TeramodModEntities.HAKAIDAN.get().spawn(_level, BlockPos.containing(x + Mth.nextInt(RandomSource.create(), -30, 30), y + 4, z + Mth.nextInt(RandomSource.create(), -30, 30)),
									MobSpawnType.MOB_SUMMONED);
							if (entityToSpawn != null) {
								entityToSpawn.setYRot(world.getRandom().nextFloat() * 360F);
							}
						}
					}
					entity.getPersistentData().putDouble("kerutime", 0);
				}
				if (r == 3) {
					for (int index1 = 0; index1 < 10; index1++) {
						if (world instanceof ServerLevel _level)
							_level.sendParticles(ParticleTypes.END_ROD, x, y, z, 100, 5, 5, 5, 10);
					}
					TeramodMod.queueServerWork(20, () -> {
						if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
							_entity.addEffect(new MobEffectInstance(TeramodModMobEffects.STAN.get(), 190, 1, true, true));
						if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
							_entity.addEffect(new MobEffectInstance(TeramodModMobEffects.SUIKOMI.get(), 200, 1, true, true));
					});
					entity.getPersistentData().putDouble("kerutime", 0);
				}
				if (r >= 4) {
					if (r <= 5) {
						if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
							_entity.addEffect(new MobEffectInstance(TeramodModMobEffects.TOSSIN.get(), 100, Mth.nextInt(RandomSource.create(), 0, 3), true, true));
						entity.getPersistentData().putDouble("kerutime", 0);
					}
				}
			}
		}
	}
}
