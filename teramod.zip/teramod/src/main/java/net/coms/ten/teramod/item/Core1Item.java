
package net.coms.ten.teramod.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class Core1Item extends Item {
	public Core1Item() {
		super(new Item.Properties().stacksTo(64).rarity(Rarity.RARE));
	}
}
