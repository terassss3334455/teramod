
package net.coms.ten.teramod.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class Core2Item extends Item {
	public Core2Item() {
		super(new Item.Properties().stacksTo(64).rarity(Rarity.RARE));
	}
}
