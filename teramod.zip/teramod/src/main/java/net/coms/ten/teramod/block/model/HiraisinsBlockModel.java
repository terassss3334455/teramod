package net.coms.ten.teramod.block.model;

import software.bernie.geckolib.model.GeoModel;

import net.minecraft.resources.ResourceLocation;

import net.coms.ten.teramod.block.entity.HiraisinsTileEntity;

public class HiraisinsBlockModel extends GeoModel<HiraisinsTileEntity> {
	@Override
	public ResourceLocation getAnimationResource(HiraisinsTileEntity animatable) {
		return new ResourceLocation("teramod", "animations/hiraisin.animation.json");
	}

	@Override
	public ResourceLocation getModelResource(HiraisinsTileEntity animatable) {
		return new ResourceLocation("teramod", "geo/hiraisin.geo.json");
	}

	@Override
	public ResourceLocation getTextureResource(HiraisinsTileEntity animatable) {
		return new ResourceLocation("teramod", "textures/block/hiraisintexture.png");
	}
}
