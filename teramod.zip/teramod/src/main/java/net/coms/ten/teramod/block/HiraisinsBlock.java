package net.coms.ten.teramod.block;

import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.storage.loot.LootParams;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.EntityBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.item.ItemStack;
import net.minecraft.core.BlockPos;

import net.coms.ten.teramod.init.TeramodModBlockEntities;
import net.coms.ten.teramod.block.entity.HiraisinsTileEntity;

import javax.annotation.Nullable;

import java.util.List;
import java.util.Collections;

public class HiraisinsBlock extends BaseEntityBlock implements EntityBlock {

    public static final IntegerProperty ANIMATION =
            IntegerProperty.create("animation", 0, 1);

    public HiraisinsBlock() {
        super(BlockBehaviour.Properties.of()
                .sound(SoundType.GRAVEL)
                .strength(1f, 10f));
    }

    @Override
    public RenderShape getRenderShape(BlockState state) {
        return RenderShape.ENTITYBLOCK_ANIMATED;
    }

    @Nullable
    @Override
    public BlockEntity newBlockEntity(BlockPos blockPos, BlockState blockState) {
        return TeramodModBlockEntities.HIRAISINS.get()
                .create(blockPos, blockState);
    }

    /*
     * BlockEntityを毎tick動かすためのTicker
     *
     * これによってHiraisinsTileEntityの
     * Hakaidan吸引処理が毎tick実行される。
     */
    @Nullable
    @Override
    public <T extends BlockEntity> BlockEntityTicker<T> getTicker(
            Level level,
            BlockState state,
            BlockEntityType<T> type) {

        return createTickerHelper(
                type,
                TeramodModBlockEntities.HIRAISINS.get(),
                HiraisinsTileEntity::tick
        );
    }

    @Override
    public boolean propagatesSkylightDown(
            BlockState state,
            BlockGetter reader,
            BlockPos pos) {

        return true;
    }

    @Override
    public int getLightBlock(
            BlockState state,
            BlockGetter worldIn,
            BlockPos pos) {

        return 0;
    }

    @Override
    protected void createBlockStateDefinition(
            StateDefinition.Builder<Block, BlockState> builder) {

        builder.add(ANIMATION);
    }

    @Override
    public BlockState getStateForPlacement(BlockPlaceContext context) {
        return this.defaultBlockState();
    }

    @Override
    public List<ItemStack> getDrops(
            BlockState state,
            LootParams.Builder builder) {

        List<ItemStack> dropsOriginal = super.getDrops(state, builder);

        if (!dropsOriginal.isEmpty()) {
            return dropsOriginal;
        }

        return Collections.singletonList(
                new ItemStack(this, 1)
        );
    }
}