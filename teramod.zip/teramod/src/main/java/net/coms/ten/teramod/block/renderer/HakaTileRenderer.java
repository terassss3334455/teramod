package net.coms.ten.teramod.block.renderer;

import software.bernie.geckolib.renderer.GeoBlockRenderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.MultiBufferSource;

import net.coms.ten.teramod.block.model.HakaBlockModel;
import net.coms.ten.teramod.block.entity.HakaTileEntity;

public class HakaTileRenderer extends GeoBlockRenderer<HakaTileEntity> {
	public HakaTileRenderer() {
		super(new HakaBlockModel());
	}

	@Override
	public RenderType getRenderType(HakaTileEntity animatable, ResourceLocation texture, MultiBufferSource bufferSource, float partialTick) {
		return RenderType.entityTranslucent(getTextureLocation(animatable));
	}
}
