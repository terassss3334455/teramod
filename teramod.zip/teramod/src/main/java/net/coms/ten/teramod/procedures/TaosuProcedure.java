package net.coms.ten.teramod.procedures;

import net.minecraftforge.items.ItemHandlerHelper;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.event.entity.living.LivingDeathEvent;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.server.level.ServerLevel;

import net.coms.ten.teramod.init.TeramodModItems;
import net.coms.ten.teramod.entity.KeruBOSSEntity;
import net.coms.ten.teramod.TeramodMod;

import javax.annotation.Nullable;

@Mod.EventBusSubscriber
public class TaosuProcedure {
	@SubscribeEvent
	public static void onEntityDeath(LivingDeathEvent event) {
		if (event != null && event.getEntity() != null) {
			execute(event, event.getEntity().level(), event.getEntity().getX(), event.getEntity().getY(), event.getEntity().getZ(), event.getEntity(), event.getSource().getEntity());
		}
	}

	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity, Entity sourceentity) {
		execute(null, world, x, y, z, entity, sourceentity);
	}

	private static void execute(@Nullable Event event, LevelAccessor world, double x, double y, double z, Entity entity, Entity sourceentity) {
		if (entity == null || sourceentity == null)
			return;
		if (!(entity == null)) {
			if (entity instanceof KeruBOSSEntity) {
				if (!(sourceentity == null)) {
					if (sourceentity instanceof Player _player) {
						ItemStack _setstack = new ItemStack(TeramodModItems.DOROXTUPU.get()).copy();
						_setstack.setCount(12);
						ItemHandlerHelper.giveItemToPlayer(_player, _setstack);
					}
					TeramodMod.queueServerWork(20, () -> {
						for (int index0 = 0; index0 < 20; index0++) {
							if (world instanceof ServerLevel _level) {
								ItemEntity entityToSpawn = new ItemEntity(_level, x, y, z, new ItemStack(TeramodModItems.DOROXTUPU.get()));
								entityToSpawn.setPickUpDelay(10);
								entityToSpawn.setUnlimitedLifetime();
								_level.addFreshEntity(entityToSpawn);
							}
						}
					});
				}
			}
		}
	}
}
