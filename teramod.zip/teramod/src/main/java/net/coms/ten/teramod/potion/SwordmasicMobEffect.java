package net.coms.ten.teramod.potion;

import net.coms.ten.teramod.entity.SwordmobEntity;
import net.coms.ten.teramod.init.TeramodModEntities;

import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.server.level.ServerLevel;

import java.util.ArrayList;
import java.util.List;

public class SwordmasicMobEffect extends MobEffect {

    private static final int MAX_SWORD_MOBS = 5;

    private static final double BASE_HEALTH = 40.0D;
    private static final double BASE_ATTACK = 15.0D;

    // エフェクトレベル1上昇ごとに50%上昇
    private static final double STAT_MULTIPLIER_PER_LEVEL = 0.5D;

    public SwordmasicMobEffect() {
        super(MobEffectCategory.NEUTRAL, -1);
    }

    @Override
    public boolean isInstantenous() {
        return false;
    }

    @Override
    public List<ItemStack> getCurativeItems() {
        return new ArrayList<ItemStack>();
    }

    @Override
    public boolean isDurationEffectTick(int duration, int amplifier) {
        return true;
    }

    @Override
    public void applyEffectTick(LivingEntity owner, int amplifier) {

        if (owner.level().isClientSide()) {
            return;
        }

        if (!(owner.level() instanceof ServerLevel serverLevel)) {
            return;
        }

        /*
         * 新しくエフェクトを持った
         */
        boolean wasActive = owner.getPersistentData()
                .getBoolean("SwordmasicWasActive");

        if (!wasActive) {

            owner.getPersistentData()
                    .putBoolean("SwordmasicWasActive", true);

            summonMissingSwordMobs(
                    serverLevel,
                    owner,
                    amplifier
            );

            // トーテム使用音
            serverLevel.playSound(
                    null,
                    owner.blockPosition(),
                    SoundEvents.TOTEM_USE,
                    owner.getSoundSource(),
                    1.0F,
                    1.0F
            );

            return;
        }

        /*
         * 現在のSwordmobを取得
         */
        List<SwordmobEntity> swordMobs =
                getOwnedSwordMobs(
                        serverLevel,
                        owner
                );

        /*
         * 全滅
         */
        if (swordMobs.isEmpty()) {

            owner.getPersistentData()
                    .putBoolean(
                            "SwordmasicWasActive",
                            false
                    );

            owner.removeEffect(this);

            serverLevel.playSound(
                    null,
                    owner.blockPosition(),
                    SoundEvents.TOTEM_USE,
                    owner.getSoundSource(),
                    1.0F,
                    1.0F
            );

            return;
        }

        /*
         * 5体未満なら不足分を召喚
         */
        if (swordMobs.size() < MAX_SWORD_MOBS) {

            summonMissingSwordMobs(
                    serverLevel,
                    owner,
                    amplifier
            );
        }

        /*
         * 既存個体も現在のレベルに合わせる
         * そして全回復
         */
        swordMobs =
                getOwnedSwordMobs(
                        serverLevel,
                        owner
                );

        double maxHealth =
                calculateHealth(amplifier);

        double attackDamage =
                calculateAttack(amplifier);

        for (SwordmobEntity swordMob : swordMobs) {

            if (swordMob.getAttribute(
                    net.minecraft.world.entity.ai.attributes.Attributes.MAX_HEALTH
            ) != null) {

                swordMob.getAttribute(
                        net.minecraft.world.entity.ai.attributes.Attributes.MAX_HEALTH
                ).setBaseValue(maxHealth);
            }

            if (swordMob.getAttribute(
                    net.minecraft.world.entity.ai.attributes.Attributes.ATTACK_DAMAGE
            ) != null) {

                swordMob.getAttribute(
                        net.minecraft.world.entity.ai.attributes.Attributes.ATTACK_DAMAGE
                ).setBaseValue(attackDamage);
            }

            swordMob.setSwordmasicAmplifier(amplifier);

            // 全回復
            swordMob.setHealth((float) maxHealth);
        }
    }

    /**
     * 足りないSwordmobを召喚
     */
    private void summonMissingSwordMobs(
            ServerLevel level,
            LivingEntity owner,
            int amplifier
    ) {

        List<SwordmobEntity> existing =
                getOwnedSwordMobs(
                        level,
                        owner
                );

        int missing =
                MAX_SWORD_MOBS - existing.size();

        if (missing <= 0) {
            return;
        }

        double maxHealth =
                calculateHealth(amplifier);

        double attackDamage =
                calculateAttack(amplifier);

        for (int i = 0; i < missing; i++) {

            SwordmobEntity swordMob =
                    TeramodModEntities.SWORDMOB.get()
                            .create(level);

            if (swordMob == null) {
                continue;
            }

            /*
             * 主人の周囲に配置
             */
            int index =
                    existing.size() + i;

            double angle =
                    index
                            * (Math.PI * 2.0D / MAX_SWORD_MOBS);

            double radius = 2.5D;

            double x =
                    owner.getX()
                            + Math.cos(angle) * radius;

            double y =
                    owner.getY() + 1.0D;

            double z =
                    owner.getZ()
                            + Math.sin(angle) * radius;

            swordMob.moveTo(
                    x,
                    y,
                    z,
                    owner.getYRot(),
                    0.0F
            );

            /*
             * 主人を記録
             */
            swordMob.setOwnerUUID(
                    owner.getUUID()
            );

            /*
             * エフェクトレベル
             */
            swordMob.setSwordmasicAmplifier(
                    amplifier
            );

            /*
             * ステータス
             */
            swordMob.getAttribute(
                    net.minecraft.world.entity.ai.attributes.Attributes.MAX_HEALTH
            ).setBaseValue(maxHealth);

            swordMob.getAttribute(
                    net.minecraft.world.entity.ai.attributes.Attributes.ATTACK_DAMAGE
            ).setBaseValue(attackDamage);

            swordMob.setHealth(
                    (float) maxHealth
            );

            /*
             * 壁抜け
             */
            swordMob.noPhysics = true;
            swordMob.setNoGravity(true);

            level.addFreshEntity(
                    swordMob
            );

            existing.add(
                    swordMob
            );
        }
    }

    /**
     * 主人が召喚したSwordmobを取得
     */
    public static List<SwordmobEntity> getOwnedSwordMobs(
            ServerLevel level,
            LivingEntity owner
    ) {

        List<SwordmobEntity> result =
                new ArrayList<>();

        /*
         * 主人から256ブロック以内
         */
        for (SwordmobEntity swordMob :
                level.getEntitiesOfClass(
                        SwordmobEntity.class,
                        owner.getBoundingBox().inflate(256.0D)
                )) {

            if (!swordMob.isAlive()) {
                continue;
            }

            if (owner.getUUID().equals(
                    swordMob.getOwnerUUID()
            )) {

                result.add(
                        swordMob
                );
            }
        }

        return result;
    }

    /**
     * 最大HP計算
     *
     * amplifier 0 = レベル1
     * amplifier 1 = レベル2
     */
    public static double calculateHealth(
            int amplifier
    ) {

        return BASE_HEALTH
                * (
                1.0D
                        + STAT_MULTIPLIER_PER_LEVEL
                        * amplifier
        );
    }

    /**
     * 攻撃力計算
     */
    public static double calculateAttack(
            int amplifier
    ) {

        return BASE_ATTACK
                * (
                1.0D
                        + STAT_MULTIPLIER_PER_LEVEL
                        * amplifier
        );
    }
}