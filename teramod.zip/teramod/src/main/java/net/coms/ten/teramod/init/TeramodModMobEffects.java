
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.coms.ten.teramod.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.effect.MobEffect;

import net.coms.ten.teramod.potion.TossinMobEffect;
import net.coms.ten.teramod.potion.SwordmasicMobEffect;
import net.coms.ten.teramod.potion.SuikomiMobEffect;
import net.coms.ten.teramod.potion.StanMobEffect;
import net.coms.ten.teramod.TeramodMod;

public class TeramodModMobEffects {
	public static final DeferredRegister<MobEffect> REGISTRY = DeferredRegister.create(ForgeRegistries.MOB_EFFECTS, TeramodMod.MODID);
	public static final RegistryObject<MobEffect> STAN = REGISTRY.register("stan", () -> new StanMobEffect());
	public static final RegistryObject<MobEffect> SUIKOMI = REGISTRY.register("suikomi", () -> new SuikomiMobEffect());
	public static final RegistryObject<MobEffect> SWORDMASIC = REGISTRY.register("swordmasic", () -> new SwordmasicMobEffect());
	public static final RegistryObject<MobEffect> TOSSIN = REGISTRY.register("tossin", () -> new TossinMobEffect());
}
