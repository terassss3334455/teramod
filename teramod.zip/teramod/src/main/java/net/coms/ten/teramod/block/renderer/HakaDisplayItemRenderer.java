package net.coms.ten.teramod.block.renderer;

import software.bernie.geckolib.renderer.GeoItemRenderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.MultiBufferSource;

import net.coms.ten.teramod.block.model.HakaDisplayModel;
import net.coms.ten.teramod.block.display.HakaDisplayItem;

public class HakaDisplayItemRenderer extends GeoItemRenderer<HakaDisplayItem> {
	public HakaDisplayItemRenderer() {
		super(new HakaDisplayModel());
	}

	@Override
	public RenderType getRenderType(HakaDisplayItem animatable, ResourceLocation texture, MultiBufferSource bufferSource, float partialTick) {
		return RenderType.entityTranslucent(getTextureLocation(animatable));
	}
}
