
package net.coms.ten.teramod.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class Core3Item extends Item {
	public Core3Item() {
		super(new Item.Properties().stacksTo(64).rarity(Rarity.RARE));
	}
}
