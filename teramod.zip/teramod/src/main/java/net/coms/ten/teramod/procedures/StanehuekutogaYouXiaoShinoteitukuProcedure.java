package net.coms.ten.teramod.procedures;

import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.Mob;

public class StanehuekutogaYouXiaoShinoteitukuProcedure {

    public static void execute(Entity entity) {
        if (entity instanceof Mob mob) {
            mob.setNoAi(true);
            mob.setTarget(null);
            mob.setDeltaMovement(
                0,
                mob.getDeltaMovement().y,
                0
            );
        }
    }
}