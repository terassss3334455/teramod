package net.coms.ten.teramod.potion;

import net.coms.ten.teramod.entity.HakaidanEntity;
import net.coms.ten.teramod.init.TeramodModMobEffects;

import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.List;

public class SuikomiMobEffect extends MobEffect {

    private static final String COLLECTED_ITEM_KEY =
        "SuikomiCollectedItems";

    /*
     * =========================================================
     * レベルごとの基本設定
     * =========================================================
     *
     * レベル1
     *  吸引範囲      15ブロック
     *  通常ダメージ  10
     *  吸引力        通常
     *
     * レベル2
     *  吸引範囲      18ブロック
     *  通常ダメージ  15
     *  吸引力        レベル1より強い
     *
     * レベル3
     *  吸引範囲      21ブロック
     *  通常ダメージ  20
     *  吸引力        レベル2より強い
     *
     * 以降もレベルに応じて上昇。
     */

    private static final double BASE_SUCTION_RANGE = 15.0D;
    private static final double SUCTION_RANGE_PER_LEVEL = 3.0D;

    private static final float BASE_DAMAGE = 10.0F;
    private static final float DAMAGE_PER_LEVEL = 5.0F;

    /*
     * 通常エンティティの最大吸引速度
     */
    private static final double BASE_MAX_SPEED = 1.8D;
    private static final double MAX_SPEED_PER_LEVEL = 0.25D;

    /*
     * アイテムの最大吸引速度
     */
    private static final double BASE_ITEM_MAX_SPEED = 2.2D;
    private static final double ITEM_MAX_SPEED_PER_LEVEL = 0.30D;

    /*
     * HakaidanEntityとの接触距離
     */
    private static final double HAKAIDAN_RANGE = 4.0D;

    /*
     * アイテムを消す距離
     */
    private static final double ITEM_DELETE_RANGE = 3.0D;

    public SuikomiMobEffect() {
        super(MobEffectCategory.NEUTRAL, -1);
    }

    @Override
    public boolean isInstantenous() {
        return false;
    }

    @Override
    public boolean isDurationEffectTick(
        int duration,
        int amplifier
    ) {
        return true;
    }

    @Override
    public void applyEffectTick(
        LivingEntity entity,
        int amplifier
    ) {

        if (entity == null || entity.level() == null) {
            return;
        }

        Level level = entity.level();

        /*
         * クライアントでは処理しない
         */
        if (level.isClientSide()) {
            return;
        }

        /*
         * =========================================================
         * エフェクトレベル
         * =========================================================
         *
         * amplifier 0 → レベル1
         * amplifier 1 → レベル2
         * amplifier 2 → レベル3
         */
        int effectLevel = amplifier + 1;

        /*
         * =========================================================
         * レベルによる各種数値
         * =========================================================
         */

        double suctionRange =
            BASE_SUCTION_RANGE
            + (effectLevel - 1)
            * SUCTION_RANGE_PER_LEVEL;

        float damageAmount =
            BASE_DAMAGE
            + (effectLevel - 1)
            * DAMAGE_PER_LEVEL;

        double maxSpeed =
            BASE_MAX_SPEED
            + (effectLevel - 1)
            * MAX_SPEED_PER_LEVEL;

        double itemMaxSpeed =
            BASE_ITEM_MAX_SPEED
            + (effectLevel - 1)
            * ITEM_MAX_SPEED_PER_LEVEL;

        /*
         * 現在のSuikomiの残り時間を取得
         */
        MobEffectInstance suikomiEffect =
            entity.getEffect(this);

        if (suikomiEffect == null) {
            return;
        }

        int remainingDuration =
            suikomiEffect.getDuration();

        /*
         * =========================================================
         * 吸引範囲
         * =========================================================
         */

        AABB suctionArea =
            entity.getBoundingBox()
                .inflate(suctionRange);

        Vec3 center =
            entity.position();

        /*
         * =========================================================
         * エンティティ吸引
         * =========================================================
         */

        List<Entity> entities =
            level.getEntitiesOfClass(
                Entity.class,
                suctionArea,
                target ->
                    target != null
                    && target != entity
                    && !target.isRemoved()
            );

        for (Entity target : entities) {

            Vec3 difference =
                center.subtract(
                    target.position()
                );

            double distance =
                difference.length();

            if (
                distance <= 0.001D
                || distance > suctionRange
            ) {
                continue;
            }

            Vec3 direction =
                difference.normalize();

            /*
             * =====================================================
             * レベルに応じた吸引力
             * =====================================================
             *
             * 基本値 × レベル補正
             */
            double levelMultiplier =
                1.0D
                + ((effectLevel - 1) * 0.25D);

            double strength;

            /*
             * 遠距離
             */
            if (distance > suctionRange * 0.66D) {

                strength =
                    0.18D * levelMultiplier;

            /*
             * 中距離
             */
            } else if (distance > suctionRange * 0.46D) {

                strength =
                    0.28D * levelMultiplier;

            /*
             * 近距離
             */
            } else if (distance > suctionRange * 0.26D) {

                strength =
                    0.40D * levelMultiplier;

            /*
             * 至近距離
             */
            } else {

                strength =
                    0.55D * levelMultiplier;
            }

            Vec3 velocity =
                target.getDeltaMovement();

            Vec3 newVelocity =
                velocity.add(
                    direction.scale(strength)
                );

            /*
             * 最大速度
             */
            if (newVelocity.length() > maxSpeed) {

                newVelocity =
                    newVelocity.normalize()
                        .scale(maxSpeed);
            }

            target.setDeltaMovement(
                newVelocity
            );

            target.hurtMarked = true;
        }

        /*
         * =========================================================
         * アイテム吸引
         * =========================================================
         */

        List<ItemEntity> items =
            level.getEntitiesOfClass(
                ItemEntity.class,
                suctionArea,
                item ->
                    item != null
                    && !item.isRemoved()
            );

        int collectedThisTick = 0;

        for (ItemEntity item : items) {

            Vec3 difference =
                center.subtract(
                    item.position()
                );

            double distance =
                difference.length();

            if (
                distance <= 0.001D
                || distance > suctionRange
            ) {
                continue;
            }

            Vec3 direction =
                difference.normalize();

            double levelMultiplier =
                1.0D
                + ((effectLevel - 1) * 0.25D);

            double strength;

            if (distance > suctionRange * 0.66D) {

                strength =
                    0.25D * levelMultiplier;

            } else if (distance > suctionRange * 0.46D) {

                strength =
                    0.40D * levelMultiplier;

            } else if (distance > suctionRange * 0.26D) {

                strength =
                    0.60D * levelMultiplier;

            } else {

                strength =
                    0.85D * levelMultiplier;
            }

            Vec3 velocity =
                item.getDeltaMovement();

            Vec3 newVelocity =
                velocity.add(
                    direction.scale(strength)
                );

            if (
                newVelocity.length()
                > itemMaxSpeed
            ) {

                newVelocity =
                    newVelocity.normalize()
                        .scale(itemMaxSpeed);
            }

            item.setDeltaMovement(
                newVelocity
            );

            item.hasImpulse = true;

            /*
             * =====================================================
             * 半径3ブロック以内でアイテム消去
             * =====================================================
             */

            if (distance <= ITEM_DELETE_RANGE) {

                int count =
                    item.getItem().getCount();

                if (count > 0) {
                    collectedThisTick += count;
                }

                item.discard();
            }
        }

        /*
         * =========================================================
         * 回収アイテム数
         * =========================================================
         */

        int collectedItems =
            entity.getPersistentData()
                .getInt(COLLECTED_ITEM_KEY);

        if (collectedThisTick > 0) {

            collectedItems +=
                collectedThisTick;

            entity.getPersistentData()
                .putInt(
                    COLLECTED_ITEM_KEY,
                    collectedItems
                );
        }

        /*
         * =========================================================
         * アイテム上限
         * =========================================================
         *
         * レベル1 → 200
         * レベル2 → 400
         * レベル3 → 600
         */

        int itemLimit =
            effectLevel * 200;

        if (collectedItems >= itemLimit) {

            /*
             * 上限到達時75ダメージ
             */
            entity.hurt(
                level.damageSources().generic(),
                75.0F
            );

            /*
             * STANへレベル・時間継承
             */
            applyStan(
                entity,
                amplifier,
                remainingDuration
            );

            /*
             * Suikomi削除
             */
            removeSuikomi(entity);

            return;
        }

        /*
         * =========================================================
         * 半径4ブロック以内のLivingEntity
         * =========================================================
         *
         * HakaidanEntityは除外
         */

        AABB damageArea =
            entity.getBoundingBox()
                .inflate(HAKAIDAN_RANGE);

        List<LivingEntity> livingEntities =
            level.getEntitiesOfClass(
                LivingEntity.class,
                damageArea,
                target ->
                    target != null
                    && target != entity
                    && target.isAlive()
                    && !(target instanceof HakaidanEntity)
            );

        /*
         * Generic Damage
         */
        var genericDamage =
            level.damageSources().generic();

        /*
         * =========================================================
         * 継続ダメージ
         * =========================================================
         *
         * 与えた実ダメージ分だけ
         * 吸い込み側を回復する。
         */

        for (LivingEntity target :
                livingEntities) {

            if (!target.isAlive()) {
                continue;
            }

            /*
             * ダメージ前の体力
             */
            float healthBefore =
                target.getHealth();

            /*
             * ダメージを与える
             */
            boolean damaged =
                target.hurt(
                    genericDamage,
                    damageAmount
                );

            if (damaged) {

                /*
                 * 実際に減った体力を計算
                 *
                 * 例：
                 * 10ダメージを与えた
                 * → 10回復
                 *
                 * 防具や耐性などで5しか減らなかった
                 * → 5回復
                 */
                float healthAfter =
                    target.getHealth();

                float actualDamage =
                    healthBefore
                    - healthAfter;

                if (actualDamage > 0.0F) {

                    entity.heal(
                        actualDamage
                    );
                }
            }
        }

        /*
         * =========================================================
         * HakaidanEntity専用処理
         * =========================================================
         *
         * HakaidanEntityには継続10～ダメージを与えない。
         *
         * 4ブロック以内に来た場合だけ
         * 50ダメージ + STAN。
         */

        List<HakaidanEntity> hakaidanEntities =
            level.getEntitiesOfClass(
                HakaidanEntity.class,
                damageArea,
                target ->
                    target != null
                    && target != entity
                    && target.isAlive()
            );

        for (HakaidanEntity hakaidan :
                hakaidanEntities) {

            /*
             * 50ダメージ
             */
            hakaidan.hurt(
                genericDamage,
                50.0F
            );

            /*
             * STANへレベル・残り時間継承
             */
            applyStan(
                hakaidan,
                amplifier,
                remainingDuration
            );

            /*
             * Suikomi削除
             */
            removeSuikomi(entity);

            return;
        }
    }

    /*
     * =========================================================
     * STAN付与
     * =========================================================
     */

    private void applyStan(
        LivingEntity entity,
        int amplifier,
        int duration
    ) {

        MobEffectInstance stan =
            new MobEffectInstance(
                TeramodModMobEffects.STAN.get(),
                duration,
                amplifier,
                false,
                true
            );

        entity.addEffect(stan);
    }

    /*
     * =========================================================
     * Suikomi削除
     * =========================================================
     */

    private void removeSuikomi(
        LivingEntity entity
    ) {

        entity.removeEffect(this);

        entity.getPersistentData()
            .remove(
                COLLECTED_ITEM_KEY
            );
    }
}