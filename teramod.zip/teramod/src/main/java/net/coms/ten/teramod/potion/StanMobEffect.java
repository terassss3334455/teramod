package net.coms.ten.teramod.potion;

import net.coms.ten.teramod.procedures.StanposiyonXiaoGuogaQieretaShiProcedure;
import net.coms.ten.teramod.procedures.StanehuekutogaYouXiaoShinoteitukuProcedure;
import net.coms.ten.teramod.procedures.YuukoujyouziProcedure;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.ai.attributes.AttributeMap;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.effect.MobEffect;

import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

import java.util.List;
import java.util.ArrayList;

public class StanMobEffect extends MobEffect {

    public StanMobEffect() {
        super(MobEffectCategory.NEUTRAL, -1);

        MinecraftForge.EVENT_BUS.register(this);
    }

    @Override
    public boolean isInstantenous() {
        return false;
    }

    @Override
    public List<ItemStack> getCurativeItems() {
        ArrayList<ItemStack> cures = new ArrayList<ItemStack>();
        return cures;
    }

    @Override
    public void applyInstantenousEffect(
            Entity source,
            Entity indirectSource,
            LivingEntity entity,
            int amplifier,
            double health) {

        StanehuekutogaYouXiaoShinoteitukuProcedure.execute(entity);
    }

    @Override
    public void applyEffectTick(
            LivingEntity entity,
            int amplifier) {

        if (entity instanceof Mob mob) {
            mob.setNoAi(true);
            mob.setTarget(null);

            mob.setDeltaMovement(
                0,
                mob.getDeltaMovement().y,
                0
            );
        }
    }

    @Override
    public void removeAttributeModifiers(
            LivingEntity entity,
            AttributeMap attributeMap,
            int amplifier) {

        super.removeAttributeModifiers(
            entity,
            attributeMap,
            amplifier
        );

        StanposiyonXiaoGuogaQieretaShiProcedure.execute(entity);
    }

    @Override
    public boolean isDurationEffectTick(
            int duration,
            int amplifier) {

        return true;
    }

    @SubscribeEvent
    public void onLivingHurt(LivingHurtEvent event) {

        LivingEntity entity = event.getEntity();

        if (entity.hasEffect(this)) {
            YuukoujyouziProcedure.execute(
                entity,
                event,
                this
            );
        }
    }
}