
package net.coms.ten.teramod.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class TokusyuItem extends Item {
	public TokusyuItem() {
		super(new Item.Properties().stacksTo(64).rarity(Rarity.COMMON));
	}
}
