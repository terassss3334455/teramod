package net.coms.ten.teramod.entity.model;

import software.bernie.geckolib.model.GeoModel;

import net.coms.ten.teramod.entity.SwordmobEntity;

import net.minecraft.resources.ResourceLocation;

public class SwordmobModel extends GeoModel<SwordmobEntity> {
	@Override
	public ResourceLocation getAnimationResource(SwordmobEntity entity) {
		return new ResourceLocation("teramod", "animations/swordmob.animation.json");
	}

	@Override
	public ResourceLocation getModelResource(SwordmobEntity entity) {
		return new ResourceLocation("teramod", "geo/swordmob.geo.json");
	}

	@Override
	public ResourceLocation getTextureResource(SwordmobEntity entity) {
		return new ResourceLocation("teramod", "textures/entities/" + entity.getTexture() + ".png");
	}

}
